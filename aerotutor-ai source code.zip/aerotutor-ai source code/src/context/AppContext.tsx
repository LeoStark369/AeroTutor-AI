import React, { createContext, useContext, useState, useEffect } from "react";
import {
  NavSection,
  UserProfile,
  DocumentItem,
  ChatSession,
  TutorMode,
  TopicMastery,
  Achievement,
  StudyPlan,
  StudyTask,
  QuizResult,
  AccessibilitySettings
} from "../types";
import {
  initialUserProfile,
  sampleDocuments,
  sampleTopicMastery,
  initialAchievements,
  sampleStudyPlan,
  sampleChatSessions,
  hackathonDemoSteps
} from "../data/sampleData";

interface AppContextType {
  currentSection: NavSection;
  setSection: (section: NavSection) => void;
  user: UserProfile;
  updateUser: (updates: Partial<UserProfile>) => void;
  documents: DocumentItem[];
  activeDocument: DocumentItem | null;
  setActiveDocumentId: (id: string | null) => void;
  uploadDocument: (doc: Partial<DocumentItem>) => string;
  chatSessions: ChatSession[];
  activeChat: ChatSession | null;
  setActiveChatId: (id: string | null) => void;
  createChatSession: (title: string, subject: any, docId?: string) => string;
  addChatMessage: (chatId: string, role: "user" | "assistant", content: string, mode?: TutorMode) => void;
  tutorMode: TutorMode;
  setTutorMode: (mode: TutorMode) => void;
  topicMastery: TopicMastery[];
  updateMastery: (topicName: string, newScore: number) => void;
  achievements: Achievement[];
  unlockAchievement: (id: string) => void;
  studyPlan: StudyPlan;
  studyTasks: StudyTask[];
  toggleStudyTask: (taskId: string) => void;
  toggleTaskCompletion: (taskId: string) => void;
  addStudyTask: (title: string, subject: string, date: string) => void;
  quizResults: QuizResult[];
  recordQuizResult: (result: QuizResult) => void;
  addXP: (amount: number) => void;
  accessibility: AccessibilitySettings;
  updateAccessibility: (updates: Partial<AccessibilitySettings>) => void;
  theme: "dark" | "light";
  setTheme: (theme: "dark" | "light") => void;
  isHackathonDemoActive: boolean;
  setIsHackathonDemoActive: (active: boolean) => void;
  demoStep: number;
  advanceDemoStep: () => void;
  jumpToDemoStep: (step: number) => void;
  resetData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentSection, setCurrentSection] = useState<NavSection>("dashboard");
  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem("aerotutor_user");
    return saved ? JSON.parse(saved) : initialUserProfile;
  });

  const [documents, setDocuments] = useState<DocumentItem[]>(() => {
    const saved = localStorage.getItem("aerotutor_docs");
    return saved ? JSON.parse(saved) : sampleDocuments;
  });

  const [activeDocumentId, setActiveDocumentIdState] = useState<string | null>("doc-aerodynamics");

  const [chatSessions, setChatSessions] = useState<ChatSession[]>(() => {
    const saved = localStorage.getItem("aerotutor_chats");
    return saved ? JSON.parse(saved) : sampleChatSessions;
  });

  const [activeChatId, setActiveChatIdState] = useState<string | null>("chat-aerodynamics");

  const [tutorMode, setTutorMode] = useState<TutorMode>("Engineering");

  const [topicMastery, setTopicMastery] = useState<TopicMastery[]>(() => {
    const saved = localStorage.getItem("aerotutor_mastery");
    return saved ? JSON.parse(saved) : sampleTopicMastery;
  });

  const [achievements, setAchievements] = useState<Achievement[]>(() => {
    const saved = localStorage.getItem("aerotutor_achievements");
    return saved ? JSON.parse(saved) : initialAchievements;
  });

  const [studyPlan, setStudyPlan] = useState<StudyPlan>(() => {
    const saved = localStorage.getItem("aerotutor_plan");
    return saved ? JSON.parse(saved) : sampleStudyPlan;
  });

  const [quizResults, setQuizResults] = useState<QuizResult[]>(() => {
    const saved = localStorage.getItem("aerotutor_quizzes");
    return saved ? JSON.parse(saved) : [];
  });

  const [accessibility, setAccessibility] = useState<AccessibilitySettings>(() => {
    const saved = localStorage.getItem("aerotutor_accessibility");
    return saved ? JSON.parse(saved) : { highContrast: false, dyslexicFont: false, fontSize: "normal" };
  });

  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const [isHackathonDemoActive, setIsHackathonDemoActive] = useState<boolean>(true);
  const [demoStep, setDemoStep] = useState<number>(1);

  useEffect(() => {
    localStorage.setItem("aerotutor_accessibility", JSON.stringify(accessibility));
  }, [accessibility]);

  useEffect(() => {
    localStorage.setItem("aerotutor_user", JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem("aerotutor_docs", JSON.stringify(documents));
  }, [documents]);

  useEffect(() => {
    localStorage.setItem("aerotutor_chats", JSON.stringify(chatSessions));
  }, [chatSessions]);

  useEffect(() => {
    localStorage.setItem("aerotutor_mastery", JSON.stringify(topicMastery));
  }, [topicMastery]);

  useEffect(() => {
    localStorage.setItem("aerotutor_achievements", JSON.stringify(achievements));
  }, [achievements]);

  useEffect(() => {
    localStorage.setItem("aerotutor_plan", JSON.stringify(studyPlan));
  }, [studyPlan]);

  useEffect(() => {
    localStorage.setItem("aerotutor_quizzes", JSON.stringify(quizResults));
  }, [quizResults]);

  const setSection = (section: NavSection) => {
    setCurrentSection(section);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const updateUser = (updates: Partial<UserProfile>) => {
    setUser(prev => ({ ...prev, ...updates }));
  };

  const addXP = (amount: number) => {
    setUser(prev => {
      const newXP = prev.totalXP + amount;
      const newLevel = Math.floor(newXP / 750) + 1;
      let levelTitle = prev.levelTitle;
      if (newLevel >= 6) levelTitle = "Flight Director";
      else if (newLevel >= 5) levelTitle = "Orbital Engineer";
      else if (newLevel >= 4) levelTitle = "Aerospace Cadet";
      else if (newLevel >= 3) levelTitle = "STEM Scholar";

      return {
        ...prev,
        totalXP: newXP,
        level: newLevel,
        levelTitle
      };
    });
  };

  const uploadDocument = (docData: Partial<DocumentItem>): string => {
    const id = `doc-${Date.now()}`;
    const newDoc: DocumentItem = {
      id,
      title: docData.title || "Uploaded Document",
      subject: docData.subject || "Aerospace Engineering",
      author: docData.author || "Student Upload",
      fileSize: docData.fileSize || "1.5 MB",
      uploadDate: new Date().toISOString().split("T")[0],
      progress: 0,
      content: docData.content || "",
      summary30s: docData.summary30s,
      summary5m: docData.summary5m,
      summaryDetailed: docData.summaryDetailed,
      chapters: docData.chapters || ["Chapter 1"],
      keyConcepts: docData.keyConcepts || ["Key Concept 1"],
      formulas: docData.formulas || [],
      keyTerms: docData.keyTerms || [],
      examRevision: docData.examRevision || []
    };
    setDocuments(prev => [newDoc, ...prev]);
    setActiveDocumentIdState(id);
    addXP(150);
    return id;
  };

  const activeDocument = documents.find(d => d.id === activeDocumentId) || documents[0] || null;

  const setActiveDocumentId = (id: string | null) => {
    setActiveDocumentIdState(id);
  };

  const activeChat = chatSessions.find(c => c.id === activeChatId) || chatSessions[0] || null;

  const setActiveChatId = (id: string | null) => {
    setActiveChatIdState(id);
  };

  const createChatSession = (title: string, subject: any, docId?: string): string => {
    const id = `chat-${Date.now()}`;
    const newChat: ChatSession = {
      id,
      title,
      subject,
      lastUpdated: "Just now",
      documentId: docId,
      messages: []
    };
    setChatSessions(prev => [newChat, ...prev]);
    setActiveChatIdState(id);
    return id;
  };

  const addChatMessage = (chatId: string, role: "user" | "assistant", content: string, mode?: TutorMode) => {
    setChatSessions(prev =>
      prev.map(chat => {
        if (chat.id === chatId) {
          return {
            ...chat,
            lastUpdated: "Just now",
            messages: [
              ...chat.messages,
              {
                id: `msg-${Date.now()}`,
                role,
                content,
                timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
                mode
              }
            ]
          };
        }
        return chat;
      })
    );
  };

  const updateMastery = (topicName: string, newScore: number) => {
    setTopicMastery(prev => {
      const existing = prev.find(t => t.topicName.toLowerCase() === topicName.toLowerCase());
      if (existing) {
        return prev.map(t => {
          if (t.topicName.toLowerCase() === topicName.toLowerCase()) {
            const score = Math.max(0, Math.min(100, newScore));
            let level: any = "Needs Attention";
            if (score >= 95) level = "Mastered";
            else if (score >= 80) level = "Strong";
            else if (score >= 60) level = "Improving";
            else if (score >= 40) level = "Developing";
            return { ...t, score, level, lastPracticed: "Just now" };
          }
          return t;
        });
      } else {
        let level: any = "Needs Attention";
        if (newScore >= 95) level = "Mastered";
        else if (newScore >= 80) level = "Strong";
        else if (newScore >= 60) level = "Improving";
        else if (newScore >= 40) level = "Developing";
        return [...prev, { topicName, subject: "Aerospace Engineering", score: newScore, level, lastPracticed: "Just now" }];
      }
    });
  };

  const unlockAchievement = (id: string) => {
    setAchievements(prev =>
      prev.map(a => {
        if (a.id === id && !a.unlocked) {
          addXP(a.xpReward);
          return { ...a, unlocked: true, unlockedAt: new Date().toISOString().split("T")[0], progress: a.maxProgress };
        }
        return a;
      })
    );
  };

  const updateAccessibility = (updates: Partial<AccessibilitySettings>) => {
    setAccessibility(prev => ({ ...prev, ...updates }));
  };

  const toggleStudyTask = (taskId: string) => {
    setStudyPlan(prev => ({
      ...prev,
      tasks: prev.tasks.map(t => {
        if (t.id === taskId) {
          if (!t.completed) addXP(50);
          return { ...t, completed: !t.completed };
        }
        return t;
      })
    }));
  };

  const studyTasks: StudyTask[] = studyPlan.tasks.map(t => ({
    ...t,
    taskTitle: t.taskTitle || t.topic || "Study Task",
    dueDate: t.dueDate || t.day || "Today",
    estimatedMinutes: t.estimatedMinutes || t.durationMinutes || 30
  }));

  const addStudyTask = (title: string, subject: string, date: string) => {
    const newTask: StudyTask = {
      id: `t-${Date.now()}`,
      day: date,
      dueDate: date,
      subject,
      topic: title,
      taskTitle: title,
      durationMinutes: 45,
      estimatedMinutes: 45,
      completed: false
    };
    setStudyPlan(prev => ({
      ...prev,
      tasks: [newTask, ...prev.tasks]
    }));
  };

  const recordQuizResult = (result: QuizResult) => {
    setQuizResults(prev => [result, ...prev]);
    addXP(Math.round(result.score * 10));

    // Update mastery for tested topics
    Object.entries(result.topicPerformance).forEach(([topic, acc]) => {
      updateMastery(topic, Math.round(acc));
    });

    if (result.accuracy === 100) {
      unlockAchievement("ach-5");
    }
  };

  const advanceDemoStep = () => {
    if (demoStep < hackathonDemoSteps.length) {
      const nextStep = demoStep + 1;
      setDemoStep(nextStep);
      const target = hackathonDemoSteps.find(s => s.step === nextStep)?.targetSection;
      if (target) setSection(target);
    }
  };

  const jumpToDemoStep = (stepNum: number) => {
    setDemoStep(stepNum);
    const target = hackathonDemoSteps.find(s => s.step === stepNum)?.targetSection;
    if (target) setSection(target);
  };

  const resetData = () => {
    localStorage.clear();
    setUser(initialUserProfile);
    setDocuments(sampleDocuments);
    setTopicMastery(sampleTopicMastery);
    setAchievements(initialAchievements);
    setStudyPlan(sampleStudyPlan);
    setQuizResults([]);
    setChatSessions(sampleChatSessions);
    setActiveDocumentIdState("doc-aerodynamics");
    setActiveChatIdState("chat-aerodynamics");
    setDemoStep(1);
    setCurrentSection("dashboard");
  };

  return (
    <AppContext.Provider
      value={{
        currentSection,
        setSection,
        user,
        updateUser,
        documents,
        activeDocument,
        setActiveDocumentId,
        uploadDocument,
        chatSessions,
        activeChat,
        setActiveChatId,
        createChatSession,
        addChatMessage,
        tutorMode,
        setTutorMode,
        topicMastery,
        updateMastery,
        achievements,
        unlockAchievement,
        studyPlan,
        studyTasks,
        toggleStudyTask,
        toggleTaskCompletion: toggleStudyTask,
        addStudyTask,
        quizResults,
        recordQuizResult,
        addXP,
        accessibility,
        updateAccessibility,
        theme,
        setTheme,
        isHackathonDemoActive,
        setIsHackathonDemoActive,
        demoStep,
        advanceDemoStep,
        jumpToDemoStep,
        resetData
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error("useApp must be used within AppProvider");
  return context;
};
