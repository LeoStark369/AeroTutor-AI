import { DocumentItem, TopicMastery, Achievement, UserProfile, StudyPlan, ChatSession } from "../types";

export const initialUserProfile: UserProfile = {
  name: "Alex Vance",
  email: "alex.vance@aerotutor.ai",
  ageRange: "18-22",
  educationLevel: "Undergraduate Engineering",
  country: "United States",
  language: "English",
  preferredSubjects: ["Aerospace Engineering", "Physics", "Mathematics"],
  skillLevel: "Intermediate",
  learningGoals: ["Master Aerodynamics & Lift", "Ace Orbital Mechanics Exam", "Build Aerospace Simulations"],
  learningStyle: "Practical",
  isGuest: false,
  streakDays: 7,
  totalXP: 2450,
  level: 4,
  levelTitle: "Aerospace Cadet",
};

export const sampleDocuments: DocumentItem[] = [
  {
    id: "doc-aerodynamics",
    title: "Introduction to Aerodynamics & Fluid Dynamics",
    subject: "Aerospace Engineering",
    author: "Dr. E. L. Compressible",
    fileSize: "4.2 MB",
    uploadDate: "2026-07-20",
    progress: 68,
    isDemo: true,
    content: `Chapter 1: Principles of Aerodynamic Lift and Drag
Aerodynamics is the branch of fluid dynamics concerned with studying the motion of air, particularly when it interacts with a solid object, such as an airplane wing (airfoil).

1.1 Dynamic Pressure and Continuity
For an incompressible flow, fluid continuity dictates that mass flow rate stays constant across a streamline tube:
A1 * V1 = A2 * V2

Dynamic pressure (q) is defined as:
q = 0.5 * rho * V^2
where rho is air density (1.225 kg/m^3 at sea level) and V is freestream airspeed.

1.2 Lift and Drag Coefficients
Aerodynamic lift (L) and drag (D) are defined non-dimensionally as:
L = 0.5 * rho * V^2 * S * C_L
D = 0.5 * rho * V^2 * S * C_D

where S is wing planform area, C_L is lift coefficient, and C_D is drag coefficient.
The angle of attack (AoA, alpha) directly modifies C_L. As AoA increases up to the critical stall angle (~15 degrees), C_L increases linearly:
C_L ≈ 2 * pi * alpha (in radians for thin airfoils).

Beyond critical AoA, boundary layer separation occurs leading to aerodynamic stall and sudden loss of lift.`,
    summary30s: "Explains fundamental fluid continuity, dynamic pressure q = 0.5*ρ*V², and how angle of attack controls aerodynamic lift and drag coefficients until boundary layer stall.",
    summary5m: "This textbook section provides mathematical formulations for aerodynamic forces. Key principles include fluid continuity A1V1 = A2V2, dynamic pressure, and non-dimensional lift and drag force equations. It emphasizes the physical mechanism of lift generation via upper-surface acceleration and lower pressure according to Bernoulli's equation, as well as boundary layer separation at stall angle.",
    summaryDetailed: `1. Aerodynamic Force Formulation:
   - Lift: L = 0.5 * ρ * V² * S * C_L
   - Drag: D = 0.5 * ρ * V² * S * C_D
2. Fluid Continuity & Compressibility:
   - Incompressible assumption holds below Mach 0.3.
   - Dynamic pressure q = 0.5 * ρ * V².
3. Angle of Attack (AoA) & Boundary Layer:
   - Linear lift slope C_L ≈ 2π * α for small angles.
   - Stall occurs when boundary layer separates from adverse pressure gradients.`,
    chapters: [
      "1. Principles of Aerodynamic Lift & Drag",
      "2. Bernoulli's Principle & Compressibility",
      "3. Boundary Layer Theory & Skin Friction",
      "4. Supersonic Flow & Shock Waves"
    ],
    keyConcepts: [
      "Dynamic Pressure (q)",
      "Lift Coefficient (C_L)",
      "Drag Coefficient (C_D)",
      "Angle of Attack (AoA)",
      "Boundary Layer Stall",
      "Reynolds Number (Re)"
    ],
    formulas: [
      { name: "Dynamic Pressure", formula: "q = \\frac{1}{2} \\rho V^2", description: "Kinetic energy per unit volume of moving fluid." },
      { name: "Lift Equation", formula: "L = \\frac{1}{2} \\rho V^2 S C_L", description: "Total upward aerodynamic force produced by wing area S." },
      { name: "Drag Equation", formula: "D = \\frac{1}{2} \\rho V^2 S C_D", description: "Total retarding aerodynamic drag force along flow velocity." },
      { name: "Thin Airfoil Lift Slope", formula: "C_L = 2\\pi \\alpha", description: "Theoretical lift coefficient slope per radian angle of attack." }
    ],
    keyTerms: [
      { term: "Angle of Attack (AoA)", definition: "Angle between chord line of airfoil and freestream velocity vector." },
      { term: "Boundary Layer", definition: "Thin layer of fluid adjacent to solid surface where viscous shear forces dominate." },
      { term: "Aerodynamic Stall", definition: "Reduction in lift caused by flow separation at high angle of attack." }
    ],
    examRevision: [
      "Always check units: air density ρ is kg/m³, velocity V is m/s, area S is m².",
      "Lift varies with V²: doubling velocity quadruples aerodynamic lift!",
      "Stall is caused by excessive Angle of Attack, not low airspeed directly."
    ]
  },
  {
    id: "doc-orbital",
    title: "Orbital Mechanics & Spacecraft Dynamics",
    subject: "Aerospace Engineering",
    author: "Prof. H. Kepler",
    fileSize: "6.8 MB",
    uploadDate: "2026-07-22",
    progress: 45,
    isDemo: true,
    content: `Chapter 3: Two-Body Problem and Keplerian Orbits
Orbital mechanics derives from Newton's Law of Universal Gravitation and Newton's Second Law:
F = G * M * m / r^2

3.1 Circular Orbital Velocity
For a circular orbit of radius r around central body mass M (Earth G*M = 3.986e14 m^3/s^2):
v = sqrt(G * M / r)

3.2 Escape Velocity
The speed required to escape a gravitational field to infinity is:
v_esc = sqrt(2 * G * M / r) = sqrt(2) * v_circ

3.3 Orbital Period
Kepler's Third Law relates orbit radius r to period T:
T = 2 * pi * sqrt(r^3 / (G * M))

3.4 Hohmann Transfer Orbit
To transfer between two coplanar circular orbits of radius r1 and r2, the delta-V required at pericenter injection is:
v_trans1 = sqrt(G * M / r1) * (sqrt(2*r2 / (r1 + r2)) - 1)`,
    summary30s: "Covers Keplerian orbits, circular orbital velocity v = sqrt(GM/r), escape speed v_esc = sqrt(2)*v_circ, and delta-v math for Hohmann orbit transfers.",
    summary5m: "This chapter details two-body celestial dynamics. It derives circular orbital speed, escape velocity requirements, Kepler's orbital period law, and fuel-optimal Hohmann transfers between Earth orbits.",
    summaryDetailed: `1. Circular Orbit Velocity: v = sqrt(GM / r)
2. Escape Velocity: v_esc = sqrt(2*GM / r)
3. Kepler's 3rd Law: T² ∝ r³
4. Hohmann Transfer ΔV Impulse Calculations.`,
    chapters: ["1. Kepler's Laws", "2. Two-Body Equations", "3. Circular & Elliptical Orbits", "4. Hohmann Transfers & Delta-V"],
    keyConcepts: ["Orbital Velocity", "Escape Speed", "Hohmann Transfer", "Kepler's Third Law", "Pericenter & Apocenter"],
    formulas: [
      { name: "Circular Orbital Speed", formula: "v = \\sqrt{\\frac{GM}{r}}", description: "Required speed to maintain circular orbit at radius r." },
      { name: "Escape Speed", formula: "v_{esc} = \\sqrt{\\frac{2GM}{r}}", description: "Minimum speed to escape central gravitational well." }
    ],
    keyTerms: [
      { term: "Pericenter", definition: "Point in an orbit closest to the primary body." },
      { term: "Delta-V (ΔV)", definition: "Scalar change in velocity required for an orbital maneuver." }
    ],
    examRevision: [
      "Escape velocity is always exactly sqrt(2) ≈ 1.414 times circular orbital velocity.",
      "Higher orbits have lower orbital speeds (v ∝ 1/sqrt(r))."
    ]
  },
  {
    id: "doc-physics",
    title: "University Physics: Mechanics & Vectors",
    subject: "Physics",
    author: "Dr. R. Feynman",
    fileSize: "5.1 MB",
    uploadDate: "2026-07-25",
    progress: 82,
    isDemo: true,
    content: `Vector Resolution & Newton's Laws
Vectors have both magnitude and direction. A vector A in 2D space is resolved into Cartesian components:
Ax = A * cos(theta)
Ay = A * sin(theta)

Newton's 2nd Law: F_net = m * a
In 2D vector notation: sum(Fx) = m * ax, sum(Fy) = m * ay.`,
    summary30s: "Covers 2D vector resolution (Ax = A cos θ, Ay = A sin θ) and free-body force balances via Newton's Second Law F = ma.",
    summary5m: "Foundational physics chapter covering vector dot products, component resolution, and applying vector force balances to mechanical systems.",
    summaryDetailed: `1. Vector Decomposition
2. Newton's 3 Laws of Motion
3. Work-Energy Theorem`,
    chapters: ["1. Vector Mathematics", "2. Kinematics in 2D", "3. Newton's Laws of Motion"],
    keyConcepts: ["Vector Resolution", "Newton's Laws", "Free Body Diagrams"],
    formulas: [{ name: "Newton's 2nd Law", formula: "\\vec{F} = m \\vec{a}", description: "Net force vector equals mass times acceleration vector." }],
    keyTerms: [{ term: "Vector", definition: "A mathematical quantity having both magnitude and direction." }],
    examRevision: ["Always break vectors into X and Y components before summing forces."]
  }
];

export const sampleTopicMastery: TopicMastery[] = [
  { topicName: "Newton's Laws", subject: "Physics", score: 92, level: "Strong", lastPracticed: "Today" },
  { topicName: "Kinematics", subject: "Physics", score: 81, level: "Strong", lastPracticed: "Yesterday" },
  { topicName: "Vectors & Components", subject: "Physics", score: 63, level: "Improving", lastPracticed: "2 days ago" },
  { topicName: "Lift and Drag", subject: "Aerospace Engineering", score: 68, level: "Improving", lastPracticed: "Today" },
  { topicName: "Orbital Mechanics", subject: "Aerospace Engineering", score: 55, level: "Developing", lastPracticed: "3 days ago" },
  { topicName: "Rocket Propulsion", subject: "Aerospace Engineering", score: 40, level: "Developing", lastPracticed: "4 days ago" },
  { topicName: "Calculus & Derivatives", subject: "Mathematics", score: 88, level: "Strong", lastPracticed: "5 days ago" },
  { topicName: "Sorting Algorithms", subject: "Computer Science", score: 95, level: "Mastered", lastPracticed: "1 week ago" }
];

export const initialAchievements: Achievement[] = [
  {
    id: "ach-1",
    title: "First Launch",
    description: "Complete your first lesson or document review in AeroTutor AI.",
    icon: "🚀",
    unlocked: true,
    unlockedAt: "2026-07-20",
    progress: 1,
    maxProgress: 1,
    category: "Learning",
    xpReward: 100
  },
  {
    id: "ach-2",
    title: "Knowledge Builder",
    description: "Complete 100 quiz questions across any STEM subjects.",
    icon: "🧠",
    unlocked: false,
    progress: 42,
    maxProgress: 100,
    category: "Quiz",
    xpReward: 500
  },
  {
    id: "ach-3",
    title: "Flight Ready",
    description: "Master 10 aerospace engineering concepts with 80%+ accuracy.",
    icon: "✈️",
    unlocked: false,
    progress: 4,
    maxProgress: 10,
    category: "Mastery",
    xpReward: 750
  },
  {
    id: "ach-4",
    title: "7-Day Streak",
    description: "Study for seven consecutive days without missing a session.",
    icon: "🔥",
    unlocked: true,
    unlockedAt: "2026-07-29",
    progress: 7,
    maxProgress: 7,
    category: "Streak",
    xpReward: 300
  },
  {
    id: "ach-5",
    title: "Precision",
    description: "Score a perfect 100% score on any generated STEM quiz.",
    icon: "🎯",
    unlocked: true,
    unlockedAt: "2026-07-26",
    progress: 1,
    maxProgress: 1,
    category: "Quiz",
    xpReward: 250
  },
  {
    id: "ach-6",
    title: "Orbital Thinker",
    description: "Complete the orbital mechanics simulation and practice pathway.",
    icon: "🌌",
    unlocked: false,
    progress: 60,
    maxProgress: 100,
    category: "Lab",
    xpReward: 600
  }
];

export const sampleStudyPlan: StudyPlan = {
  id: "plan-1",
  goal: "Midterm Exam Preparation - Aerospace & Physics",
  examDate: "2026-08-15",
  createdDate: "2026-07-28",
  tasks: [
    { id: "t1", day: "Monday", subject: "Aerospace Engineering", topic: "Lift & Drag Coefficients", durationMinutes: 45, completed: true, notes: "Reviewed Bernoulli principle & AoA slope" },
    { id: "t2", day: "Tuesday", subject: "Physics", topic: "Vector Component Resolution", durationMinutes: 60, completed: true, notes: "Practiced 2D free-body force diagrams" },
    { id: "t3", day: "Wednesday", subject: "Aerospace Engineering", topic: "Orbital Speed & Kepler's 3rd Law", durationMinutes: 45, completed: false, notes: "Target: v = sqrt(GM/r)" },
    { id: "t4", day: "Thursday", subject: "Mathematics", topic: "Calculus - Partial Derivatives", durationMinutes: 50, completed: false },
    { id: "t5", day: "Friday", subject: "Aerospace Engineering", topic: "Aerospace Lab - Rocket Simulation", durationMinutes: 40, completed: false },
    { id: "t6", day: "Saturday", subject: "Physics", topic: "Full Adaptive Quiz Practice", durationMinutes: 60, completed: false }
  ]
};

export const sampleChatSessions: ChatSession[] = [
  {
    id: "chat-aerodynamics",
    title: "Angle of Attack & Stall Physics",
    subject: "Aerospace Engineering",
    lastUpdated: "Today",
    documentId: "doc-aerodynamics",
    messages: [
      {
        id: "m1",
        role: "user",
        content: "Why does increasing the angle of attack affect lift?",
        timestamp: "10:14 AM"
      },
      {
        id: "m2",
        role: "assistant",
        content: `### Answer
Increasing the angle of attack (AoA) increases airflow camber deflection and pressure differential between the upper and lower airfoil surfaces, generating higher aerodynamic lift up to the critical stall angle.

### Why?
As AoA increases, fluid over the upper curved surface accelerates faster than under the flat lower surface. According to Bernoulli's principle, higher velocity results in lower static pressure above the wing, producing an upward net lift force.

### Equation
$$L = \\frac{1}{2} \\rho V^2 S C_L$$
where $C_L \\approx 2\\pi \\alpha$ (for thin airfoils at low AoA).

### Worked Example
At sea level ($\\rho = 1.225 \\text{ kg/m}^3$) with $V = 100 \\text{ m/s}$ and $S = 20 \\text{ m}^2$:
If $C_L$ increases from $0.4$ to $0.8$ when AoA increases by 4 degrees:
- Initial Lift: $L_1 = 0.5 \\times 1.225 \\times 100^2 \\times 20 \\times 0.4 = 49,000 \\text{ N}$
- New Lift: $L_2 = 98,000 \\text{ N}$

### Try It Yourself
What occurs if AoA exceeds 15 degrees? (Hint: Think about boundary layer separation!)`,
        timestamp: "10:14 AM",
        mode: "Engineering"
      }
    ]
  }
];

export const hackathonDemoSteps = [
  { step: 1, title: "Step 1: Open AeroTutor AI", description: "Welcome to AeroTutor AI, the intelligent STEM learning platform.", targetSection: "landing" as const, actionText: "Explore Platform" },
  { step: 2, title: "Step 2: Select Flagship Textbook", description: "Select 'Introduction to Aerodynamics & Fluid Dynamics' in Library.", targetSection: "library" as const, actionText: "Open Document" },
  { step: 3, title: "Step 3: Auto-Generated AI Intelligence", description: "View instant 30-sec summary, 5-min summary, formula sheets & key terms.", targetSection: "summary" as const, actionText: "Ask AI Tutor" },
  { step: 4, title: "Step 4: Ask AI Tutor a Question", description: "Ask: 'Why does increasing the angle of attack affect lift?'", targetSection: "tutor" as const, actionText: "Ask Question" },
  { step: 5, title: "Step 5: Understand Engineering Response", description: "Review answer, equations, worked example, and physical why breakdown.", targetSection: "tutor" as const, actionText: "Test Me" },
  { step: 6, title: "Step 6: Press 'Test Me' to Launch Quiz", description: "Launch automatic quiz generator for Aerodynamics.", targetSection: "quiz" as const, actionText: "Take Quiz" },
  { step: 7, title: "Step 7: Complete Quiz Assessment", description: "Answer practice questions and review instant score feedback.", targetSection: "quiz" as const, actionText: "View Diagnostics" },
  { step: 8, title: "Step 8: AI Detects Weak Concept", description: "System identifies low score in 'Vectors & Components' (63%).", targetSection: "analytics" as const, actionText: "Start Targeted Practice" },
  { step: 9, title: "Step 9: Targeted Practice Arena", description: "Solve targeted practice problems with step-by-step reasoning diagnosis.", targetSection: "practice" as const, actionText: "Open Aerospace Lab" },
  { step: 10, title: "Step 10: Aerospace Lab Simulations", description: "Interact with real-time Airfoil Explorer, Rocket, and Orbit simulators.", targetSection: "aerospace-lab" as const, actionText: "Check Progress" },
  { step: 11, title: "Step 11: Return to Dashboard", description: "See updated topic mastery, XP level increase, and new achievements!", targetSection: "dashboard" as const, actionText: "Finish Demo" }
];
