export type NavSection =
  | "landing"
  | "dashboard"
  | "tutor"
  | "library"
  | "analyzer"
  | "summary"
  | "quiz"
  | "practice"
  | "voice"
  | "aerospace-lab"
  | "stem-lab"
  | "planner"
  | "analytics"
  | "achievements"
  | "profile"
  | "settings"
  | "history";

export type TutorMode =
  | "Beginner"
  | "Student"
  | "Advanced"
  | "Engineering"
  | "Exam Mode"
  | "Socratic Mode";

export type STEMSubject =
  | "Aerospace Engineering"
  | "Physics"
  | "Mathematics"
  | "Computer Science"
  | "Engineering"
  | "Chemistry"
  | "Biology";

export interface UserProfile {
  name: string;
  email: string;
  ageRange: string;
  educationLevel: string;
  country: string;
  language: string;
  preferredSubjects: STEMSubject[];
  skillLevel: "Beginner" | "Intermediate" | "Advanced" | "Expert";
  learningGoals: string[];
  learningStyle: "Visual" | "Practical" | "Socratic" | "Mathematical";
  isGuest: boolean;
  streakDays: number;
  totalXP: number;
  level: number;
  levelTitle: string;
}

export interface DocumentFormula {
  name: string;
  formula: string;
  description: string;
}

export interface DocumentTerm {
  term: string;
  definition: string;
}

export interface DocumentItem {
  id: string;
  title: string;
  subject: STEMSubject;
  author?: string;
  fileSize?: string;
  uploadDate: string;
  content: string;
  summary30s?: string;
  summary5m?: string;
  summaryDetailed?: string;
  chapters?: string[];
  keyConcepts?: string[];
  formulas?: DocumentFormula[];
  keyTerms?: DocumentTerm[];
  examRevision?: string[];
  progress: number;
  isDemo?: boolean;
}

export interface QuizQuestion {
  id: string;
  type: "multiple-choice" | "true-false" | "numerical" | "conceptual";
  question: string;
  options?: string[];
  correctAnswer: string | number;
  explanation: string;
  conceptTag: string;
}

export interface QuizConfig {
  source: "textbook" | "chapter" | "topic" | "mistakes";
  documentId?: string;
  topic: string;
  difficulty: "Easy" | "Medium" | "Hard" | "Expert";
  questionCount: number;
}

export interface QuizResult {
  id: string;
  quizTitle: string;
  date: string;
  score: number;
  total: number;
  accuracy: number;
  timeSpentSeconds: number;
  userAnswers: Record<string, string>;
  questions: QuizQuestion[];
  topicPerformance: Record<string, number>;
}

export type MasteryLevel =
  | "Needs Attention" // 0-39%
  | "Developing"     // 40-59%
  | "Improving"      // 60-79%
  | "Strong"         // 80-94%
  | "Mastered";      // 95-100%

export interface TopicMastery {
  topicName: string;
  subject: STEMSubject;
  score: number; // 0-100
  level: MasteryLevel;
  lastPracticed: string;
}

export interface PracticeProblem {
  id: string;
  subject: STEMSubject;
  topic: string;
  question: string;
  givenData?: Record<string, string>;
  difficulty: "Easy" | "Medium" | "Hard" | "Expert";
  expectedUnits?: string;
  hint?: string;
}

export interface PracticeAttemptFeedback {
  userAttempt: string;
  isCorrect: boolean;
  whereReasoningWentWrong?: string;
  correctApproach: string;
  finalAnswer: string;
  similarProblemPrompt: string;
}

export interface AccessibilitySettings {
  highContrast: boolean;
  dyslexicFont: boolean;
  fontSize: "normal" | "large" | "extra-large";
}

export interface StudyTask {
  id: string;
  day?: string;
  dueDate?: string;
  subject: STEMSubject | string;
  topic?: string;
  taskTitle?: string;
  durationMinutes?: number;
  estimatedMinutes?: number;
  completed: boolean;
  notes?: string;
}

export interface StudyPlan {
  id: string;
  goal: string;
  examDate: string;
  createdDate: string;
  tasks: StudyTask[];
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  unlockedAt?: string;
  progress: number;
  maxProgress: number;
  category: "Learning" | "Quiz" | "Streak" | "Lab" | "Mastery";
  xpReward: number;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
  mode?: TutorMode;
  documentRef?: string;
  image?: string;
}

export interface ChatSession {
  id: string;
  title: string;
  subject: STEMSubject;
  lastUpdated: string;
  messages: ChatMessage[];
  documentId?: string;
}

export interface DemoStep {
  step: number;
  title: string;
  description: string;
  targetSection: NavSection;
  actionText?: string;
}
