import React from "react";
import { useApp } from "../context/AppContext";
import {
  Flame,
  Zap,
  BookOpen,
  Target,
  ArrowRight,
  TrendingUp,
  AlertCircle,
  Award,
  CheckCircle2,
  Clock,
  Sparkles,
  Rocket
} from "lucide-react";

export const Dashboard: React.FC = () => {
  const { user, setSection, activeDocument, topicMastery, quizResults, setIsHackathonDemoActive, jumpToDemoStep } = useApp();

  // Find strongest and weakest subjects
  const sortedTopics = [...topicMastery].sort((a, b) => b.score - a.score);
  const strongestTopic = sortedTopics[0] || { topicName: "Newton's Laws", score: 92, subject: "Physics" };
  const weakestTopic = sortedTopics[sortedTopics.length - 1] || { topicName: "Vectors & Components", score: 63, subject: "Physics" };

  const avgAccuracy = quizResults.length > 0
    ? Math.round(quizResults.reduce((acc, q) => acc + q.accuracy, 0) / quizResults.length)
    : 84;

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-7xl mx-auto">
      {/* Top Welcome Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/10 blur-3xl pointer-events-none rounded-full" />

        <div className="space-y-1 z-10">
          <div className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider">
            {user.levelTitle} • Level {user.level}
          </div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-white">
            Good morning, {user.name} 👋
          </h1>
          <p className="text-slate-400 text-xs md:text-sm max-w-xl">
            Your personalized STEM and Aerospace learning engine is ready. You have 1 active study mission today.
          </p>
        </div>

        <div className="flex items-center gap-3 z-10 self-start md:self-auto">
          <button
            onClick={() => setSection("tutor")}
            className="px-4 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold rounded-xl text-xs shadow-md shadow-cyan-500/20 flex items-center gap-2"
            id="dash-ask-tutor-btn"
          >
            <Sparkles className="w-4 h-4" />
            <span>Ask AI Tutor</span>
          </button>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4.5 rounded-2xl flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400 font-medium">Study Streak</div>
            <div className="text-2xl font-extrabold text-white mt-1 flex items-center gap-1.5">
              <span>{user.streakDays} Days</span>
              <Flame className="w-5 h-5 text-amber-400 fill-amber-400" />
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center">
            <Flame className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4.5 rounded-2xl flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400 font-medium">Total XP</div>
            <div className="text-2xl font-extrabold text-white mt-1 flex items-center gap-1.5">
              <span>{user.totalXP.toLocaleString()}</span>
              <Zap className="w-5 h-5 text-cyan-400 fill-cyan-400" />
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center">
            <Zap className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4.5 rounded-2xl flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400 font-medium">Quiz Accuracy</div>
            <div className="text-2xl font-extrabold text-white mt-1">{avgAccuracy}%</div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4.5 rounded-2xl flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400 font-medium">Mastered Topics</div>
            <div className="text-2xl font-extrabold text-white mt-1">
              {topicMastery.filter(t => t.score >= 80).length} / {topicMastery.length}
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center">
            <Award className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Main Content Split */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column (2 cols) */}
        <div className="lg:col-span-2 space-y-8">
          {/* Continue Learning Card */}
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-cyan-400" />
                <span>Continue Learning</span>
              </h2>
              <button
                onClick={() => setSection("library")}
                className="text-xs text-cyan-400 hover:text-cyan-300 font-medium flex items-center gap-1"
              >
                <span>View All Documents</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {activeDocument ? (
              <div className="bg-slate-950 border border-slate-800 p-5 rounded-xl space-y-3 hover:border-cyan-500/30 transition-all">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                      {activeDocument.subject}
                    </span>
                    <h3 className="text-base font-bold text-white mt-2">{activeDocument.title}</h3>
                    <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                      {activeDocument.summary30s || "Interactive textbook material with AI summary, formula sheets, and practice quizzes."}
                    </p>
                  </div>
                </div>

                <div className="space-y-1.5 pt-2">
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span>Course Progress</span>
                    <span className="font-semibold text-white">{activeDocument.progress}%</span>
                  </div>
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-cyan-500 to-blue-500 h-full rounded-full transition-all"
                      style={{ width: `${activeDocument.progress}%` }}
                    />
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-end gap-3">
                  <button
                    onClick={() => setSection("summary")}
                    className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-semibold rounded-lg border border-slate-700"
                  >
                    View Summary & Formulas
                  </button>
                  <button
                    onClick={() => setSection("tutor")}
                    className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold rounded-lg flex items-center gap-1.5"
                  >
                    <span>Continue Study</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-center py-6 text-slate-400 text-xs">No active document selected.</div>
            )}
          </div>

          {/* Recommended For You */}
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span>Recommended For You (AI Intelligence)</span>
            </h2>

            <div className="space-y-3">
              <div className="bg-slate-950 border border-amber-500/30 p-4 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-amber-400">Review: {weakestTopic.topicName}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 font-mono">
                      Mastery: {weakestTopic.score}%
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">
                    Reason: "Your recent quiz results show difficulty with vector resolution and force diagrams."
                  </p>
                </div>

                <button
                  onClick={() => setSection("practice")}
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-lg shrink-0"
                >
                  Start Practice
                </button>
              </div>

              <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-cyan-300">Flagship Lab: Airfoil Streamlines & Stall Boundary</span>
                  </div>
                  <p className="text-xs text-slate-400">
                    Reason: "Consolidate your aerodynamic lift knowledge with interactive airflow simulations."
                  </p>
                </div>

                <button
                  onClick={() => setSection("aerospace-lab")}
                  className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold rounded-lg shrink-0"
                >
                  Open Lab
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (1 col) */}
        <div className="space-y-8">
          {/* Today's Mission */}
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Target className="w-4 h-4 text-cyan-400" />
                <span>Today's Mission</span>
              </h2>
              <span className="text-[10px] font-mono text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/20">
                ACTIVE
              </span>
            </div>

            <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl space-y-3">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="text-xs font-bold text-white">Complete 15 questions on orbital mechanics</h3>
                  <p className="text-[11px] text-slate-400 mt-0.5">Focus: Escape velocity & Hohmann transfers</p>
                </div>
                <Rocket className="w-5 h-5 text-cyan-400 shrink-0" />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-[11px] text-slate-400">
                  <span>Progress (9/15 Questions)</span>
                  <span className="font-semibold text-cyan-400">60%</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div className="bg-cyan-400 h-full rounded-full w-[60%]" />
                </div>
              </div>

              <button
                onClick={() => setSection("quiz")}
                className="w-full py-2 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 text-xs font-bold rounded-lg transition-all"
              >
                Continue Mission Quiz
              </button>
            </div>
          </div>

          {/* Subject Mastery Snapshot */}
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
            <h2 className="text-base font-bold text-white flex items-center justify-between">
              <span>Subject Mastery</span>
              <button onClick={() => setSection("analytics")} className="text-xs text-cyan-400 font-normal hover:underline">
                Full Analytics
              </button>
            </h2>

            <div className="space-y-3">
              {topicMastery.slice(0, 4).map((item, idx) => (
                <div key={idx} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-300 font-medium">{item.topicName}</span>
                    <span className="font-mono font-bold text-cyan-400">{item.score}%</span>
                  </div>
                  <div className="w-full bg-slate-950 h-2 rounded-full border border-slate-800 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${
                        item.score >= 80 ? "bg-emerald-400" : item.score >= 60 ? "bg-cyan-400" : "bg-amber-400"
                      }`}
                      style={{ width: `${item.score}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
