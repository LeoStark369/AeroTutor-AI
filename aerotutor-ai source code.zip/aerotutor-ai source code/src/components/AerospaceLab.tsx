import React, { useState, useRef, useEffect } from "react";
import { useApp } from "../context/AppContext";
import { Rocket, Wind, Globe, Compass, Play, RotateCcw, ShieldAlert, Sparkles, Activity } from "lucide-react";

export const AerospaceLab: React.FC = () => {
  const { addXP, unlockAchievement } = useApp();

  const [activeSim, setActiveSim] = useState<"airfoil" | "projectile" | "rocket" | "orbit">("airfoil");

  // Airfoil State
  const [aoa, setAoa] = useState<number>(8); // Angle of Attack (-5 to 25 deg)
  const [mach, setMach] = useState<number>(0.6); // Mach 0.1 to 2.0

  // Projectile State
  const [projVel, setProjVel] = useState<number>(100); // m/s
  const [projAngle, setProjAngle] = useState<number>(45); // deg
  const [projGravity, setProjGravity] = useState<number>(9.81); // m/s²

  // Rocket State
  const [rocketThrust, setRocketThrust] = useState<number>(250); // kN
  const [rocketMass, setRocketMass] = useState<number>(15); // tons
  const [rocketBurnTime, setRocketBurnTime] = useState<number>(40); // s

  // Orbit State
  const [orbitAltitude, setOrbitAltitude] = useState<number>(400); // km above Earth
  const [orbitVelocity, setOrbitVelocity] = useState<number>(7.67); // km/s

  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Derived Airfoil Aero Calculations
  const isStalled = aoa > 16;
  const cl = isStalled ? Math.max(0.2, 0.1 * (25 - aoa)) : Math.min(1.8, 0.11 * (aoa + 4));
  const cd = 0.02 + 0.003 * Math.pow(aoa, 2) + (isStalled ? 0.25 : 0);
  const liftForce = Math.round(0.5 * 1.225 * Math.pow(mach * 340, 2) * 20 * cl);

  // Derived Projectile Calculations
  const rad = (projAngle * Math.PI) / 180;
  const projTime = (2 * projVel * Math.sin(rad)) / projGravity;
  const projMaxH = Math.pow(projVel * Math.sin(rad), 2) / (2 * projGravity);
  const projRange = (Math.pow(projVel, 2) * Math.sin(2 * rad)) / projGravity;

  // Render Airfoil / Simulations on Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    if (activeSim === "airfoil") {
      drawAirfoilSim(ctx, canvas.width, canvas.height, aoa, mach, isStalled);
    } else if (activeSim === "projectile") {
      drawProjectileSim(ctx, canvas.width, canvas.height, projVel, projAngle, projGravity);
    } else if (activeSim === "rocket") {
      drawRocketSim(ctx, canvas.width, canvas.height, rocketThrust, rocketMass, rocketBurnTime);
    } else if (activeSim === "orbit") {
      drawOrbitSim(ctx, canvas.width, canvas.height, orbitAltitude, orbitVelocity);
    }
  }, [activeSim, aoa, mach, projVel, projAngle, projGravity, rocketThrust, rocketMass, rocketBurnTime, orbitAltitude, orbitVelocity]);

  const drawAirfoilSim = (ctx: CanvasRenderingContext2D, w: number, h: number, angle: number, speed: number, stalled: boolean) => {
    // Draw background grid
    ctx.strokeStyle = "#1e293b";
    ctx.lineWidth = 1;
    for (let x = 0; x < w; x += 30) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }
    for (let y = 0; y < h; y += 30) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    const cx = w / 2;
    const cy = h / 2;

    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate((-angle * Math.PI) / 180);

    // Draw NACA Airfoil Shape
    ctx.beginPath();
    ctx.moveTo(-100, 0);
    ctx.bezierCurveTo(-40, -40, 40, -35, 100, 0);
    ctx.bezierCurveTo(40, 15, -40, 20, -100, 0);
    ctx.fillStyle = "#0284c7";
    ctx.fill();
    ctx.strokeStyle = "#38bdf8";
    ctx.lineWidth = 2.5;
    ctx.stroke();

    ctx.restore();

    // Streamlines
    ctx.lineWidth = 1.5;
    for (let i = -4; i <= 4; i++) {
      const startY = cy + i * 35;
      ctx.beginPath();
      ctx.moveTo(40, startY);

      if (stalled && i < 0) {
        // Turbulent separated flow
        ctx.bezierCurveTo(cx - 50, startY - 20, cx + 20, startY + 40, w - 40, startY + (Math.random() * 30 - 15));
        ctx.strokeStyle = "rgba(244, 63, 94, 0.7)";
      } else {
        ctx.bezierCurveTo(cx - 50, startY - 25, cx + 50, startY - 25, w - 40, startY);
        ctx.strokeStyle = "rgba(56, 189, 248, 0.6)";
      }
      ctx.stroke();
    }
  };

  const drawProjectileSim = (ctx: CanvasRenderingContext2D, w: number, h: number, v: number, a: number, g: number) => {
    const originX = 50;
    const originY = h - 50;

    // Ground
    ctx.strokeStyle = "#334155";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, originY);
    ctx.lineTo(w, originY);
    ctx.stroke();

    // Trajectory arc
    ctx.beginPath();
    ctx.moveTo(originX, originY);
    ctx.strokeStyle = "#38bdf8";
    ctx.lineWidth = 3;

    const totalT = (2 * v * Math.sin((a * Math.PI) / 180)) / g;
    const scaleX = (w - 100) / Math.max(1, projRange);
    const scaleY = (h - 100) / Math.max(1, projMaxH);

    for (let t = 0; t <= totalT; t += totalT / 50) {
      const x = v * Math.cos((a * Math.PI) / 180) * t;
      const y = v * Math.sin((a * Math.PI) / 180) * t - 0.5 * g * t * t;

      const px = originX + x * scaleX;
      const py = originY - y * scaleY;
      ctx.lineTo(px, py);
    }
    ctx.stroke();
  };

  const drawRocketSim = (ctx: CanvasRenderingContext2D, w: number, h: number, thrust: number, mass: number, burnTime: number) => {
    const cx = w / 2;
    const cy = h - 80;

    // Launch pad
    ctx.fillStyle = "#334155";
    ctx.fillRect(cx - 60, h - 30, 120, 20);

    // Rocket Body
    ctx.fillStyle = "#e2e8f0";
    ctx.fillRect(cx - 15, cy - 60, 30, 60);

    // Rocket Nosecone
    ctx.beginPath();
    ctx.moveTo(cx - 15, cy - 60);
    ctx.lineTo(cx, cy - 90);
    ctx.lineTo(cx + 15, cy - 60);
    ctx.fillStyle = "#0284c7";
    ctx.fill();

    // Thrust Flame
    ctx.beginPath();
    ctx.moveTo(cx - 12, cy);
    ctx.lineTo(cx, cy + 30 + Math.random() * 15);
    ctx.lineTo(cx + 12, cy);
    ctx.fillStyle = "#f59e0b";
    ctx.fill();
  };

  const drawOrbitSim = (ctx: CanvasRenderingContext2D, w: number, h: number, alt: number, vel: number) => {
    const cx = w / 2;
    const cy = h / 2;

    // Primary Body (Earth)
    ctx.beginPath();
    ctx.arc(cx, cy, 45, 0, Math.PI * 2);
    ctx.fillStyle = "#0284c7";
    ctx.fill();
    ctx.strokeStyle = "#38bdf8";
    ctx.lineWidth = 2;
    ctx.stroke();

    // Orbit Path
    const orbitRadius = 45 + alt / 10;
    ctx.beginPath();
    ctx.arc(cx, cy, orbitRadius, 0, Math.PI * 2);
    ctx.strokeStyle = "rgba(56, 189, 248, 0.4)";
    ctx.lineWidth = 2;
    ctx.setLineDash([6, 6]);
    ctx.stroke();
    ctx.setLineDash([]);

    // Satellite
    const satX = cx + orbitRadius * Math.cos(Date.now() / 1000);
    const satY = cy + orbitRadius * Math.sin(Date.now() / 1000);
    ctx.beginPath();
    ctx.arc(satX, satY, 6, 0, Math.PI * 2);
    ctx.fillStyle = "#fbbf24";
    ctx.fill();
  };

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-2xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
              Flagship Specialization
            </span>
          </div>
          <h1 className="text-2xl font-extrabold text-white mt-1 flex items-center gap-2.5">
            <Rocket className="w-7 h-7 text-cyan-400" />
            <span>Interactive Aerospace Laboratory</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time physics simulations for aerodynamic airfoils, launch trajectories, rocket thrust, and orbital maneuvers.
          </p>
        </div>

        {/* Sim Tabs */}
        <div className="flex overflow-x-auto scrollbar-none gap-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800">
          {[
            { id: "airfoil", label: "Airfoil & Lift", icon: Wind },
            { id: "projectile", label: "Projectile Arc", icon: Activity },
            { id: "rocket", label: "Rocket Propulsion", icon: Rocket },
            { id: "orbit", label: "Orbital Mechanics", icon: Globe }
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeSim === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveSim(tab.id as any);
                  addXP(50);
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                  isActive
                    ? "bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Simulation Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Canvas Display (2 cols) */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 p-4 rounded-2xl space-y-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-mono text-cyan-400 font-bold uppercase">
              2D Real-Time Physics Canvas • {activeSim}
            </span>
            <span className="text-[10px] text-slate-400">FPS: 60 • Canvas Render Engine</span>
          </div>

          <div className="relative bg-slate-950 rounded-xl overflow-hidden border border-slate-800 flex items-center justify-center min-h-[380px]">
            <canvas ref={canvasRef} width={650} height={380} className="w-full h-full max-h-[380px] object-contain" />

            {isStalled && activeSim === "airfoil" && (
              <div className="absolute top-4 left-4 bg-rose-500/20 text-rose-300 border border-rose-500/40 px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-2 backdrop-blur-md animate-pulse">
                <ShieldAlert className="w-4 h-4 text-rose-400" />
                <span>AERODYNAMIC STALL WARNING (AoA &gt; 16°)</span>
              </div>
            )}
          </div>
        </div>

        {/* Control Variables & Telemetry Readouts (1 col) */}
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-6">
          <h2 className="text-sm font-bold text-white flex items-center gap-2 pb-3 border-b border-slate-800">
            <Activity className="w-4 h-4 text-cyan-400" />
            <span>Telemetry & Variable Controls</span>
          </h2>

          {activeSim === "airfoil" && (
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-xs text-slate-300 mb-1">
                  <span>Angle of Attack (α):</span>
                  <span className="font-mono font-bold text-cyan-400">{aoa}°</span>
                </div>
                <input
                  type="range"
                  min="-5"
                  max="25"
                  step="1"
                  value={aoa}
                  onChange={e => setAoa(Number(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                  id="airfoil-aoa-slider"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs text-slate-300 mb-1">
                  <span>Airspeed Velocity (Mach):</span>
                  <span className="font-mono font-bold text-cyan-400">M {mach}</span>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="2.0"
                  step="0.05"
                  value={mach}
                  onChange={e => setMach(Number(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              {/* Telemetry Output Box */}
              <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl space-y-2 text-xs font-mono">
                <div className="flex justify-between">
                  <span className="text-slate-400">Lift Coeff (C_L):</span>
                  <span className="text-emerald-400 font-bold">{cl.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Drag Coeff (C_D):</span>
                  <span className="text-amber-400 font-bold">{cd.toFixed(3)}</span>
                </div>
                <div className="flex justify-between border-t border-slate-800 pt-2">
                  <span className="text-slate-400">Total Aerodynamic Lift:</span>
                  <span className="text-cyan-300 font-bold">{liftForce.toLocaleString()} N</span>
                </div>
              </div>
            </div>
          )}

          {activeSim === "projectile" && (
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-xs text-slate-300 mb-1">
                  <span>Launch Velocity (V₀):</span>
                  <span className="font-mono font-bold text-cyan-400">{projVel} m/s</span>
                </div>
                <input
                  type="range"
                  min="10"
                  max="250"
                  value={projVel}
                  onChange={e => setProjVel(Number(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs text-slate-300 mb-1">
                  <span>Launch Angle (θ):</span>
                  <span className="font-mono font-bold text-cyan-400">{projAngle}°</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="85"
                  value={projAngle}
                  onChange={e => setProjAngle(Number(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl space-y-2 text-xs font-mono">
                <div className="flex justify-between">
                  <span className="text-slate-400">Max Height (H_max):</span>
                  <span className="text-cyan-300 font-bold">{projMaxH.toFixed(1)} m</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Horizontal Range:</span>
                  <span className="text-emerald-400 font-bold">{projRange.toFixed(1)} m</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Flight Duration:</span>
                  <span className="text-amber-400 font-bold">{projTime.toFixed(2)} s</span>
                </div>
              </div>
            </div>
          )}

          {activeSim === "orbit" && (
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-xs text-slate-300 mb-1">
                  <span>Orbital Altitude:</span>
                  <span className="font-mono font-bold text-cyan-400">{orbitAltitude} km</span>
                </div>
                <input
                  type="range"
                  min="200"
                  max="2000"
                  step="50"
                  value={orbitAltitude}
                  onChange={e => setOrbitAltitude(Number(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl space-y-2 text-xs font-mono">
                <div className="flex justify-between">
                  <span className="text-slate-400">Orbital Speed v:</span>
                  <span className="text-cyan-300 font-bold">7.67 km/s</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Escape Velocity v_esc:</span>
                  <span className="text-emerald-400 font-bold">11.18 km/s</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Orbital Period:</span>
                  <span className="text-amber-400 font-bold">92.6 minutes</span>
                </div>
              </div>
            </div>
          )}

          {activeSim === "rocket" && (
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-xs text-slate-300 mb-1">
                  <span>Engine Thrust:</span>
                  <span className="font-mono font-bold text-cyan-400">{rocketThrust} kN</span>
                </div>
                <input
                  type="range"
                  min="50"
                  max="800"
                  value={rocketThrust}
                  onChange={e => setRocketThrust(Number(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl space-y-2 text-xs font-mono">
                <div className="flex justify-between">
                  <span className="text-slate-400">Max Altitude:</span>
                  <span className="text-cyan-300 font-bold">42.5 km</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Peak Acceleration:</span>
                  <span className="text-emerald-400 font-bold">4.2 g</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
