import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { NavSection } from "../types";
import {
  Rocket,
  LayoutDashboard,
  Bot,
  BookOpen,
  FileSearch,
  FileText,
  HelpCircle,
  Target,
  Mic,
  Compass,
  FlaskConical,
  Calendar,
  BarChart3,
  Award,
  History,
  User,
  Settings,
  Menu,
  X,
  Flame,
  Zap,
  Sparkles
} from "lucide-react";

interface NavItem {
  id: NavSection;
  label: string;
  icon: React.ElementType;
  badge?: string;
}

export const Navigation: React.FC = () => {
  const { currentSection, setSection, user } = useApp();
  const [mobileOpen, setMobileOpen] = useState(false);

  const mainNav: NavItem[] = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "tutor", label: "AI Tutor", icon: Bot, badge: "AI" },
    { id: "library", label: "Textbook Library", icon: BookOpen },
    { id: "analyzer", label: "Doc Analyzer", icon: FileSearch },
    { id: "summary", label: "AI Summaries", icon: FileText },
    { id: "quiz", label: "Quiz Generator", icon: HelpCircle },
    { id: "practice", label: "Practice Arena", icon: Target },
    { id: "voice", label: "Voice Tutor", icon: Mic },
    { id: "aerospace-lab", label: "Aerospace Lab", icon: Rocket, badge: "Flagship" },
    { id: "stem-lab", label: "STEM Lab", icon: FlaskConical },
    { id: "planner", label: "Study Planner", icon: Calendar },
    { id: "analytics", label: "Progress Analytics", icon: BarChart3 },
    { id: "achievements", label: "Achievements", icon: Award },
    { id: "history", label: "Tutor History", icon: History }
  ];

  const bottomNav: NavItem[] = [
    { id: "profile", label: "Profile", icon: User },
    { id: "settings", label: "Settings", icon: Settings }
  ];

  const handleNavClick = (id: NavSection) => {
    setSection(id);
    setMobileOpen(false);
  };

  return (
    <>
      {/* Mobile Top Bar */}
      <div className="lg:hidden bg-slate-900 border-b border-slate-800 px-4 py-3 flex items-center justify-between sticky top-0 z-30">
        <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => handleNavClick("dashboard")}>
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-slate-950 shadow-md shadow-cyan-500/20">
            <Rocket className="w-5 h-5" />
          </div>
          <div>
            <h1 className="font-bold text-sm tracking-wide text-white flex items-center gap-1.5">
              AeroTutor <span className="text-cyan-400 font-mono text-xs">AI</span>
            </h1>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 bg-amber-500/10 text-amber-400 text-xs px-2.5 py-1 rounded-full border border-amber-500/20">
            <Flame className="w-3.5 h-3.5 fill-amber-400" />
            <span className="font-semibold">{user.streakDays}d</span>
          </div>

          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="p-2 text-slate-300 hover:text-white bg-slate-800 rounded-lg"
            id="mobile-menu-toggle-btn"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer Overlay */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-40 bg-slate-950/80 backdrop-blur-sm flex flex-col">
          <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Rocket className="w-5 h-5 text-cyan-400" />
              <span className="font-bold text-white">AeroTutor AI</span>
            </div>
            <button onClick={() => setMobileOpen(false)} className="p-1 text-slate-400 hover:text-white">
              <X className="w-6 h-6" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-1">
            {mainNav.map((item) => {
              const Icon = item.icon;
              const isActive = currentSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-medium text-sm transition-all ${
                    isActive
                      ? "bg-cyan-500/15 text-cyan-300 border border-cyan-500/30"
                      : "text-slate-300 hover:bg-slate-800/60"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className={`w-4 h-4 ${isActive ? "text-cyan-400" : "text-slate-400"}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
            <div className="pt-4 border-t border-slate-800/60 mt-4 space-y-1">
              {bottomNav.map((item) => {
                const Icon = item.icon;
                const isActive = currentSection === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavClick(item.id)}
                    className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                      isActive ? "bg-slate-800 text-white" : "text-slate-400 hover:bg-slate-800/40"
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex flex-col w-64 bg-slate-900 border-r border-slate-800 shrink-0 h-screen sticky top-0 overflow-y-auto scrollbar-none">
        {/* Header Branding */}
        <div className="p-5 border-b border-slate-800/80">
          <div
            className="flex items-center gap-3 cursor-pointer group"
            onClick={() => handleNavClick("dashboard")}
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 via-blue-600 to-indigo-600 flex items-center justify-center text-slate-950 shadow-lg shadow-cyan-500/25 group-hover:scale-105 transition-transform">
              <Rocket className="w-6 h-6 stroke-[2.2]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-white text-lg tracking-tight">AeroTutor</span>
                <span className="px-1.5 py-0.5 text-[10px] font-mono font-bold bg-cyan-500/20 text-cyan-400 rounded border border-cyan-500/30">
                  AI
                </span>
              </div>
              <p className="text-[11px] text-slate-400">STEM & Aerospace Intelligence</p>
            </div>
          </div>
        </div>

        {/* Student Status Quick Widget */}
        <div className="mx-3 my-3 p-3 bg-slate-950/60 rounded-xl border border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 flex items-center justify-center font-bold text-xs">
              L{user.level}
            </div>
            <div>
              <div className="text-xs font-semibold text-white truncate max-w-[110px]">{user.name}</div>
              <div className="text-[10px] text-cyan-400 font-mono">{user.levelTitle}</div>
            </div>
          </div>
          <div className="flex items-center gap-1 bg-amber-500/10 text-amber-400 text-xs px-2 py-0.5 rounded-full border border-amber-500/20 font-bold">
            <Flame className="w-3.5 h-3.5 fill-amber-400" />
            <span>{user.streakDays}</span>
          </div>
        </div>

        {/* Navigation Sections */}
        <div className="flex-1 px-3 py-2 space-y-1">
          <div className="text-[10px] uppercase font-mono tracking-wider text-slate-400 px-3 py-1 font-semibold">
            Learning Workspace
          </div>
          {mainNav.map((item) => {
            const Icon = item.icon;
            const isActive = currentSection === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all group ${
                  isActive
                    ? "bg-gradient-to-r from-cyan-500/20 to-blue-600/10 text-cyan-300 font-semibold border border-cyan-500/30 shadow-sm"
                    : "text-slate-300 hover:bg-slate-800/60 hover:text-white"
                }`}
                id={`nav-item-${item.id}`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon
                    className={`w-4 h-4 transition-colors ${
                      isActive ? "text-cyan-400" : "text-slate-400 group-hover:text-cyan-400"
                    }`}
                  />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span className="text-[9px] font-mono font-bold uppercase px-1.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Bottom Profile / Settings */}
        <div className="p-3 border-t border-slate-800/80 space-y-1">
          {bottomNav.map((item) => {
            const Icon = item.icon;
            const isActive = currentSection === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium transition-all ${
                  isActive ? "bg-slate-800 text-white font-semibold" : "text-slate-400 hover:bg-slate-800/40 hover:text-slate-200"
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </aside>
    </>
  );
};
