import React from "react";
import { useApp } from "../context/AppContext";
import {
  Rocket,
  BookOpen,
  Bot,
  Brain,
  Mic,
  BarChart2,
  Zap,
  CheckCircle2,
  ArrowRight,
  FileText,
  HelpCircle,
  Sparkles,
  ShieldCheck,
  Compass
} from "lucide-react";

export const LandingPage: React.FC = () => {
  const { setSection, setIsHackathonDemoActive, jumpToDemoStep } = useApp();

  const features = [
    {
      icon: Bot,
      title: "AI Tutor",
      desc: "Ask questions and receive explanations adapted to your skill level—from beginner intuitive analogies to rigorous engineering derivations."
    },
    {
      icon: BookOpen,
      title: "Smart Textbooks",
      desc: "Upload educational documents (PDFs, notes, textbooks) and interact directly with content to extract formulas, summaries, and key terms."
    },
    {
      icon: Brain,
      title: "Adaptive Practice",
      desc: "Generate targeted questions dynamically calibrated to your mastery level in aerospace mechanics, physics, and STEM fields."
    },
    {
      icon: Mic,
      title: "Voice Learning",
      desc: "Talk to your AI tutor naturally using speech recognition and customizable text-to-speech audio controls."
    },
    {
      icon: Rocket,
      title: "Aerospace Lab",
      desc: "Explore flagship aerospace concepts through real-time interactive simulations for airfoils, projectile motion, rocket launches, and Keplerian orbits."
    },
    {
      icon: BarChart2,
      title: "Learning Intelligence",
      desc: "Track concept mastery over time, discover weak subjects automatically, and follow AI-generated personalized study plans."
    }
  ];

  const workflow = [
    { step: "01", title: "Upload Material", desc: "Drag & drop textbooks, PDFs, or lecture notes.", icon: FileText },
    { step: "02", title: "AI Understanding", desc: "Instant extraction of formulas, chapters, & key terms.", icon: Sparkles },
    { step: "03", title: "Personalized Lesson", desc: "Multi-modal Q&A with Socratic mode option.", icon: Bot },
    { step: "04", title: "Adaptive Quiz", desc: "Auto-generated questions with step-by-step diagnostic feedback.", icon: HelpCircle },
    { step: "05", title: "Mastery & Progress", desc: "Simulate physics labs & track skill progression.", icon: BarChart2 }
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* Hero Header */}
      <section className="relative overflow-hidden pt-12 pb-20 px-4 md:px-8 border-b border-slate-800/80">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-cyan-500/10 blur-[120px] rounded-full pointer-events-none" />

        <div className="max-w-5xl mx-auto text-center relative z-10 space-y-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900 border border-cyan-500/30 text-cyan-300 text-xs font-semibold shadow-inner">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span>Intelligent STEM & Aerospace Learning Engine</span>
          </div>

          <h1 className="text-4xl md:text-6xl font-extrabold text-white tracking-tight leading-tight">
            Turn Any Textbook Into Your <br />
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 via-blue-400 to-indigo-400">
              Personal AI Tutor.
            </span>
          </h1>

          <p className="text-base md:text-xl text-slate-300 max-w-3xl mx-auto leading-relaxed font-normal">
            Upload your learning material, ask questions, generate practice problems, learn by voice, and build a personalized STEM learning path with AI.
          </p>

          <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => setSection("dashboard")}
              className="w-full sm:w-auto px-8 py-3.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold rounded-xl shadow-lg shadow-cyan-500/25 text-sm transition-all flex items-center justify-center gap-2 group"
              id="landing-start-btn"
            >
              <span>Start Learning</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              onClick={() => {
                setIsHackathonDemoActive(true);
                jumpToDemoStep(1);
              }}
              className="w-full sm:w-auto px-8 py-3.5 bg-slate-900 hover:bg-slate-800 text-slate-200 font-semibold rounded-xl border border-slate-700 text-sm transition-all flex items-center justify-center gap-2"
              id="landing-explore-btn"
            >
              <Zap className="w-4 h-4 text-yellow-400" />
              <span>Explore AeroTutor Demo</span>
            </button>
          </div>

          {/* Key Audience Tags */}
          <div className="pt-6 flex flex-wrap items-center justify-center gap-2 text-xs text-slate-400">
            <span className="text-slate-500 font-mono">FLAGSHIP:</span>
            <span className="px-3 py-1 bg-cyan-950/60 text-cyan-300 rounded-full border border-cyan-500/30 font-medium">Aerospace Engineering</span>
            <span className="px-3 py-1 bg-slate-900 text-slate-300 rounded-full border border-slate-800">Physics</span>
            <span className="px-3 py-1 bg-slate-900 text-slate-300 rounded-full border border-slate-800">Mathematics</span>
            <span className="px-3 py-1 bg-slate-900 text-slate-300 rounded-full border border-slate-800">Computer Science</span>
            <span className="px-3 py-1 bg-slate-900 text-slate-300 rounded-full border border-slate-800">Fluid Dynamics</span>
          </div>
        </div>
      </section>

      {/* Visual Workflow Pipeline */}
      <section className="py-16 px-4 md:px-8 bg-slate-900/50 border-b border-slate-800">
        <div className="max-w-6xl mx-auto space-y-10">
          <div className="text-center space-y-2">
            <h2 className="text-2xl md:text-3xl font-bold text-white">How AeroTutor AI Works</h2>
            <p className="text-slate-400 text-sm">A unified educational ecosystem from document upload to subject mastery.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 relative">
            {workflow.map((item, idx) => {
              const Icon = item.icon;
              return (
                <div key={idx} className="bg-slate-900 border border-slate-800 p-5 rounded-2xl relative group hover:border-cyan-500/40 transition-all">
                  <div className="text-xs font-mono font-bold text-cyan-400 mb-2">{item.step}</div>
                  <div className="w-10 h-10 rounded-xl bg-cyan-500/10 text-cyan-300 flex items-center justify-center mb-3">
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="font-bold text-sm text-white mb-1">{item.title}</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">{item.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-16 px-4 md:px-8 max-w-6xl mx-auto space-y-12">
        <div className="text-center space-y-3">
          <h2 className="text-3xl font-extrabold text-white">Core Intelligent Features</h2>
          <p className="text-slate-400 text-sm max-w-2xl mx-auto">
            Designed specifically for STEM and Aerospace students needing clarity, step-by-step problem solving, and interactive lab feedback.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feat, idx) => {
            const Icon = feat.icon;
            return (
              <div key={idx} className="bg-slate-900 border border-slate-800/80 p-6 rounded-2xl space-y-3 hover:border-cyan-500/30 transition-all">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500/20 to-blue-600/10 border border-cyan-500/30 text-cyan-300 flex items-center justify-center">
                  <Icon className="w-6 h-6 stroke-[2]" />
                </div>
                <h3 className="text-lg font-bold text-white">{feat.title}</h3>
                <p className="text-xs text-slate-400 leading-relaxed">{feat.desc}</p>
              </div>
            );
          })}
        </div>

        {/* CTA Banner */}
        <div className="bg-gradient-to-r from-slate-900 via-cyan-950/40 to-slate-900 border border-cyan-500/30 p-8 rounded-3xl text-center space-y-6">
          <h3 className="text-2xl md:text-3xl font-bold text-white">Ready to elevate your STEM and Aerospace learning?</h3>
          <p className="text-slate-300 text-sm max-w-xl mx-auto">
            Access pre-loaded aerodynamics textbooks, run real-time orbit simulations, generate quizzes, and talk to your AI tutor today.
          </p>
          <button
            onClick={() => setSection("dashboard")}
            className="px-8 py-3.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-sm rounded-xl shadow-lg shadow-cyan-500/30 transition-all inline-flex items-center gap-2"
          >
            <Rocket className="w-4 h-4" />
            <span>Launch AeroTutor Workspace</span>
          </button>
        </div>
      </section>
    </div>
  );
};
