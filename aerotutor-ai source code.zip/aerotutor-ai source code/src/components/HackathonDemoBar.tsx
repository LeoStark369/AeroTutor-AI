import React from "react";
import { useApp } from "../context/AppContext";
import { hackathonDemoSteps } from "../data/sampleData";
import { Zap, ChevronRight, X, Play } from "lucide-react";

export const HackathonDemoBar: React.FC = () => {
  const { isHackathonDemoActive, setIsHackathonDemoActive, demoStep, advanceDemoStep, jumpToDemoStep } = useApp();

  if (!isHackathonDemoActive) {
    return (
      <button
        onClick={() => setIsHackathonDemoActive(true)}
        className="fixed bottom-4 right-4 z-50 flex items-center gap-2 px-3.5 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded-full shadow-lg shadow-cyan-900/40 text-xs font-semibold tracking-wide transition-all"
        id="hackathon-demo-launcher-btn"
      >
        <Zap className="w-4 h-4 text-yellow-300 animate-pulse" />
        Hackathon Judge Demo Flow
      </button>
    );
  }

  const currentStepObj = hackathonDemoSteps.find(s => s.step === demoStep) || hackathonDemoSteps[0];

  return (
    <div className="bg-slate-900/95 border-b border-cyan-500/30 backdrop-blur-md sticky top-0 z-40 px-4 py-2.5 shadow-xl" id="hackathon-demo-bar">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2.5 text-cyan-400 font-semibold tracking-wide shrink-0">
          <span className="flex items-center justify-center w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-[11px] font-mono">
            ⚡
          </span>
          <span className="text-white font-medium">JUDGE DEMO FLOW</span>
          <span className="text-slate-400 font-normal">({demoStep}/{hackathonDemoSteps.length})</span>
        </div>

        <div className="flex-1 overflow-x-auto scrollbar-none flex items-center gap-1.5 py-1">
          {hackathonDemoSteps.map((s) => (
            <button
              key={s.step}
              onClick={() => jumpToDemoStep(s.step)}
              className={`px-2 py-1 rounded-md transition-all text-[11px] whitespace-nowrap flex items-center gap-1 ${
                s.step === demoStep
                  ? "bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20"
                  : s.step < demoStep
                  ? "bg-slate-800 text-cyan-400 hover:bg-slate-700"
                  : "bg-slate-800/40 text-slate-400 hover:bg-slate-800"
              }`}
              title={s.description}
            >
              <span>{s.step}.</span>
              <span className="max-w-[120px] truncate">{s.title.replace(/^Step \d+: /, "")}</span>
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2 shrink-0 self-end md:self-auto">
          <button
            onClick={advanceDemoStep}
            disabled={demoStep >= hackathonDemoSteps.length}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold rounded-lg shadow-sm text-xs transition-all disabled:opacity-40"
            id="demo-next-step-btn"
          >
            <Play className="w-3.5 h-3.5 fill-slate-950" />
            <span>{currentStepObj.actionText || "Next Step"}</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setIsHackathonDemoActive(false)}
            className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg"
            title="Close Demo Bar"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
