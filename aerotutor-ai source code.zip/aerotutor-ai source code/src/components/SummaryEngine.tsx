import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import {
  FileText,
  Clock,
  BookOpen,
  CheckCircle2,
  HelpCircle,
  Sparkles,
  ArrowRight,
  ListOrdered,
  BookMarked
} from "lucide-react";

export const SummaryEngine: React.FC = () => {
  const { activeDocument, documents, setActiveDocumentId, setSection } = useApp();
  const [activeTab, setActiveTab] = useState<"30s" | "5m" | "detailed" | "formulas" | "terms" | "revision">("30s");

  if (!activeDocument) {
    return (
      <div className="p-8 text-center text-slate-400 space-y-4">
        <p>No document selected for AI Summary analysis.</p>
        <button onClick={() => setSection("library")} className="px-4 py-2 bg-cyan-500 text-slate-950 font-bold rounded-xl text-xs">
          Open Document Library
        </button>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-6xl mx-auto">
      {/* Top Header */}
      <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
              {activeDocument.subject}
            </span>
            <h1 className="text-2xl font-extrabold text-white mt-2">{activeDocument.title}</h1>
            <p className="text-xs text-slate-400 mt-1">AI-generated summary sheets, governing formulas, key definitions, and exam points.</p>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={activeDocument.id}
              onChange={e => setActiveDocumentId(e.target.value)}
              className="bg-slate-950 border border-slate-800 text-xs text-white px-3 py-2 rounded-xl focus:outline-none"
            >
              {documents.map(d => (
                <option key={d.id} value={d.id}>
                  {d.title}
                </option>
              ))}
            </select>

            <button
              onClick={() => setSection("tutor")}
              className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold rounded-xl flex items-center gap-1.5"
            >
              <BookMarked className="w-4 h-4" />
              <span>Ask AI Tutor</span>
            </button>
          </div>
        </div>

        {/* Tab Navigation Bar */}
        <div className="flex overflow-x-auto scrollbar-none gap-2 border-t border-slate-800 pt-4">
          {[
            { id: "30s", label: "30-Sec Summary", icon: Clock },
            { id: "5m", label: "5-Min Summary", icon: BookOpen },
            { id: "detailed", label: "Detailed Breakdown", icon: FileText },
            { id: "formulas", label: "Formula Sheet", icon: ListOrdered },
            { id: "terms", label: "Key Terms", icon: Sparkles },
            { id: "revision", label: "Exam Revision", icon: CheckCircle2 }
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-2 border ${
                  isActive
                    ? "bg-cyan-500/20 text-cyan-300 border-cyan-500/40 shadow-sm"
                    : "bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Content Card */}
      <div className="bg-slate-900 border border-slate-800 p-6 md:p-8 rounded-2xl min-h-[350px]">
        {activeTab === "30s" && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-cyan-400 font-bold text-sm">
              <Clock className="w-4 h-4" />
              <span>30-Second Executive Summary</span>
            </div>
            <p className="text-sm md:text-base text-slate-200 leading-relaxed bg-slate-950 p-6 rounded-2xl border border-slate-800 font-medium">
              "{activeDocument.summary30s || activeDocument.content.slice(0, 300)}"
            </p>
          </div>
        )}

        {activeTab === "5m" && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-cyan-400 font-bold text-sm">
              <BookOpen className="w-4 h-4" />
              <span>5-Minute Comprehensive Overview</span>
            </div>
            <div className="text-xs md:text-sm text-slate-300 leading-relaxed bg-slate-950 p-6 rounded-2xl border border-slate-800 whitespace-pre-wrap">
              {activeDocument.summary5m || activeDocument.content}
            </div>
          </div>
        )}

        {activeTab === "detailed" && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-cyan-400 font-bold text-sm">
              <FileText className="w-4 h-4" />
              <span>Detailed Section-by-Section Analysis</span>
            </div>
            <div className="text-xs md:text-sm text-slate-300 leading-relaxed bg-slate-950 p-6 rounded-2xl border border-slate-800 whitespace-pre-wrap">
              {activeDocument.summaryDetailed || activeDocument.content}
            </div>
          </div>
        )}

        {activeTab === "formulas" && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <ListOrdered className="w-4 h-4 text-cyan-400" />
                <span>Governing Mathematical Formulas</span>
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {activeDocument.formulas && activeDocument.formulas.length > 0 ? (
                activeDocument.formulas.map((f, idx) => (
                  <div key={idx} className="bg-slate-950 border border-slate-800 p-5 rounded-2xl space-y-2">
                    <div className="text-xs font-bold text-cyan-300">{f.name}</div>
                    <div className="bg-slate-900 border border-slate-800 p-3 rounded-xl font-mono text-sm text-yellow-300 text-center">
                      {f.formula}
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">{f.description}</p>
                  </div>
                ))
              ) : (
                <p className="text-xs text-slate-400">No formula sheet data extracted.</p>
              )}
            </div>
          </div>
        )}

        {activeTab === "terms" && (
          <div className="space-y-6">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span>Key STEM Vocabulary & Definitions</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {activeDocument.keyTerms && activeDocument.keyTerms.length > 0 ? (
                activeDocument.keyTerms.map((t, idx) => (
                  <div key={idx} className="bg-slate-950 border border-slate-800 p-4 rounded-xl space-y-1">
                    <div className="text-xs font-bold text-cyan-400">{t.term}</div>
                    <p className="text-xs text-slate-300 leading-relaxed">{t.definition}</p>
                  </div>
                ))
              ) : (
                <p className="text-xs text-slate-400">No terms extracted.</p>
              )}
            </div>
          </div>
        )}

        {activeTab === "revision" && (
          <div className="space-y-6">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>High-Value Exam Revision Points</span>
            </h3>

            <div className="space-y-3">
              {activeDocument.examRevision && activeDocument.examRevision.length > 0 ? (
                activeDocument.examRevision.map((bullet, idx) => (
                  <div key={idx} className="bg-slate-950 border border-slate-800 p-4 rounded-xl flex items-start gap-3 text-xs text-slate-200">
                    <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-[10px] font-bold shrink-0">
                      {idx + 1}
                    </div>
                    <p className="leading-relaxed">{bullet}</p>
                  </div>
                ))
              ) : (
                <p className="text-xs text-slate-400">No exam revision points found.</p>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
