import React, { useState, useEffect } from "react";
import { useApp } from "../context/AppContext";
import { QuizQuestion, QuizResult } from "../types";
import {
  HelpCircle,
  CheckCircle2,
  XCircle,
  Clock,
  Sparkles,
  Award,
  ArrowRight,
  RotateCcw,
  BookOpen
} from "lucide-react";

export const QuizGenerator: React.FC = () => {
  const { activeDocument, recordQuizResult, setSection, topicMastery } = useApp();

  // Config State
  const [topic, setTopic] = useState("Aerodynamics & Lift");
  const [difficulty, setDifficulty] = useState<"Easy" | "Medium" | "Hard" | "Expert">("Medium");
  const [questionCount, setQuestionCount] = useState<number>(5);
  const [source, setSource] = useState<"textbook" | "chapter" | "topic" | "mistakes">("textbook");

  // Active Quiz Playing State
  const [isPlaying, setIsPlaying] = useState(false);
  const [loading, setLoading] = useState(false);
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<Record<string, string>>({});
  const [startTime, setStartTime] = useState<number>(0);

  // Post Quiz Results State
  const [quizResult, setQuizResult] = useState<QuizResult | null>(null);

  const startQuiz = async () => {
    setLoading(true);
    setQuizResult(null);
    setUserAnswers({});
    setCurrentIndex(0);

    try {
      const docCtx = source === "textbook" && activeDocument ? activeDocument.content : "";
      const res = await fetch("/api/gemini/generate-quiz", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          topic: source === "textbook" && activeDocument ? activeDocument.title : topic,
          difficulty,
          questionCount,
          documentContext: docCtx
        })
      });

      const data = await res.json();
      const qList: QuizQuestion[] = data.questions || [];

      if (qList.length > 0) {
        setQuestions(qList);
        setIsPlaying(true);
        setStartTime(Date.now());
      } else {
        alert("Unable to generate quiz questions. Please check connection.");
      }
    } catch (err) {
      console.error(err);
      alert("Failed to connect to quiz generator API.");
    } finally {
      setLoading(false);
    }
  };

  const handleSelectAnswer = (qId: string, answer: string) => {
    setUserAnswers(prev => ({ ...prev, [qId]: answer }));
  };

  const finishQuiz = () => {
    const elapsedSeconds = Math.max(1, Math.round((Date.now() - startTime) / 1000));
    let correctCount = 0;
    const topicPerf: Record<string, number> = {};

    questions.forEach(q => {
      const userAns = (userAnswers[q.id] || "").trim().toLowerCase();
      const correctAns = String(q.correctAnswer).trim().toLowerCase();
      const isCorrect = userAns === correctAns || (q.type === "numerical" && Math.abs(parseFloat(userAns) - parseFloat(correctAns)) < 5);

      if (isCorrect) correctCount++;

      const tag = q.conceptTag || topic;
      topicPerf[tag] = isCorrect ? 90 : 45;
    });

    const accuracy = Math.round((correctCount / questions.length) * 100);

    const result: QuizResult = {
      id: `quiz-${Date.now()}`,
      quizTitle: `${topic} (${difficulty})`,
      date: new Date().toLocaleDateString(),
      score: correctCount,
      total: questions.length,
      accuracy,
      timeSpentSeconds: elapsedSeconds,
      userAnswers,
      questions,
      topicPerformance: topicPerf
    };

    recordQuizResult(result);
    setQuizResult(result);
    setIsPlaying(false);
  };

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-4xl mx-auto">
      {/* Quiz Config Form */}
      {!isPlaying && !quizResult && (
        <div className="bg-slate-900 border border-slate-800 p-6 md:p-8 rounded-2xl space-y-6">
          <div className="space-y-2">
            <h1 className="text-2xl font-extrabold text-white flex items-center gap-2.5">
              <HelpCircle className="w-6 h-6 text-cyan-400" />
              <span>Automatic STEM Quiz Generator</span>
            </h1>
            <p className="text-xs text-slate-400">
              Generate AI-powered multiple-choice, conceptual, and numerical practice questions.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Source Material</label>
              <select
                value={source}
                onChange={e => setSource(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              >
                <option value="textbook">Active Textbook ({activeDocument?.title || "Aerodynamics"})</option>
                <option value="topic">Custom Topic Prompt</option>
                <option value="mistakes">Target Weakest Concepts</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Difficulty Level</label>
              <select
                value={difficulty}
                onChange={e => setDifficulty(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              >
                <option>Easy</option>
                <option>Medium</option>
                <option>Hard</option>
                <option>Expert</option>
              </select>
            </div>

            {source === "topic" && (
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-300 mb-1">Topic Name</label>
                <input
                  type="text"
                  value={topic}
                  onChange={e => setTopic(e.target.value)}
                  placeholder="e.g. Orbital Speed & Kepler's 3rd Law"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Number of Questions</label>
              <select
                value={questionCount}
                onChange={e => setQuestionCount(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              >
                <option value={5}>5 Questions</option>
                <option value={10}>10 Questions</option>
                <option value={20}>20 Questions</option>
                <option value={30}>30 Questions</option>
              </select>
            </div>
          </div>

          <button
            onClick={startQuiz}
            disabled={loading}
            className="w-full py-3 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20 disabled:opacity-50"
            id="start-quiz-btn"
          >
            {loading ? (
              <>
                <Sparkles className="w-4 h-4 animate-spin" />
                <span>Generating STEM Questions...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Generate & Begin Quiz</span>
              </>
            )}
          </button>
        </div>
      )}

      {/* Playing Quiz Interface */}
      {isPlaying && questions.length > 0 && (
        <div className="bg-slate-900 border border-slate-800 p-6 md:p-8 rounded-2xl space-y-6">
          <div className="flex items-center justify-between text-xs text-slate-400 pb-3 border-b border-slate-800">
            <span>
              Question {currentIndex + 1} of {questions.length}
            </span>
            <span className="font-mono text-cyan-400 font-bold">{questions[currentIndex].conceptTag}</span>
          </div>

          <div className="space-y-4">
            <h2 className="text-base md:text-lg font-bold text-white leading-relaxed">
              {questions[currentIndex].question}
            </h2>

            {questions[currentIndex].options && questions[currentIndex].options!.length > 0 ? (
              <div className="space-y-2.5">
                {questions[currentIndex].options!.map((opt, idx) => {
                  const isSelected = userAnswers[questions[currentIndex].id] === opt;
                  return (
                    <button
                      key={idx}
                      onClick={() => handleSelectAnswer(questions[currentIndex].id, opt)}
                      className={`w-full p-3.5 rounded-xl text-xs text-left font-medium border transition-all flex items-center justify-between ${
                        isSelected
                          ? "bg-cyan-500/20 text-cyan-300 border-cyan-500/50 shadow-md"
                          : "bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700"
                      }`}
                    >
                      <span>{opt}</span>
                      {isSelected && <CheckCircle2 className="w-4 h-4 text-cyan-400" />}
                    </button>
                  );
                })}
              </div>
            ) : (
              <div>
                <label className="block text-xs text-slate-400 mb-1">Enter Numerical Value or Calculation:</label>
                <input
                  type="text"
                  value={userAnswers[questions[currentIndex].id] || ""}
                  onChange={e => handleSelectAnswer(questions[currentIndex].id, e.target.value)}
                  placeholder="e.g. 7709"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-500 font-mono"
                />
              </div>
            )}
          </div>

          <div className="pt-4 flex items-center justify-between border-t border-slate-800">
            <button
              onClick={() => setCurrentIndex(prev => Math.max(0, prev - 1))}
              disabled={currentIndex === 0}
              className="px-4 py-2 bg-slate-950 text-slate-400 text-xs font-semibold rounded-xl disabled:opacity-30"
            >
              Previous
            </button>

            {currentIndex < questions.length - 1 ? (
              <button
                onClick={() => setCurrentIndex(prev => prev + 1)}
                className="px-6 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold rounded-xl"
              >
                Next Question
              </button>
            ) : (
              <button
                onClick={finishQuiz}
                className="px-6 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold rounded-xl shadow-lg shadow-emerald-950/40"
                id="finish-quiz-btn"
              >
                Submit & Score Quiz
              </button>
            )}
          </div>
        </div>
      )}

      {/* Quiz Results Review */}
      {quizResult && (
        <div className="bg-slate-900 border border-slate-800 p-6 md:p-8 rounded-2xl space-y-6">
          <div className="text-center space-y-2 py-4 bg-slate-950 border border-slate-800 rounded-2xl">
            <div className="text-4xl font-extrabold text-cyan-400 font-mono">{quizResult.accuracy}%</div>
            <div className="text-sm font-bold text-white">
              Score: {quizResult.score} / {quizResult.total} Correct
            </div>
            <p className="text-xs text-slate-400">Time: {quizResult.timeSpentSeconds} seconds</p>
          </div>

          <div className="space-y-4">
            <h3 className="text-sm font-bold text-white">Detailed Explanation Review</h3>
            {quizResult.questions.map((q, idx) => {
              const uAns = quizResult.userAnswers[q.id] || "No Answer";
              const cAns = String(q.correctAnswer);
              const isCorrect = uAns.trim().toLowerCase() === cAns.trim().toLowerCase();
              return (
                <div key={idx} className="bg-slate-950 border border-slate-800 p-4 rounded-xl space-y-2 text-xs">
                  <div className="flex items-start justify-between gap-2">
                    <span className="font-bold text-white">
                      Q{idx + 1}. {q.question}
                    </span>
                    {isCorrect ? (
                      <span className="text-emerald-400 font-semibold flex items-center gap-1 shrink-0">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Correct
                      </span>
                    ) : (
                      <span className="text-rose-400 font-semibold flex items-center gap-1 shrink-0">
                        <XCircle className="w-3.5 h-3.5" /> Incorrect
                      </span>
                    )}
                  </div>

                  <div className="text-slate-400">
                    Your Answer: <span className="text-white font-mono">{uAns}</span>
                  </div>
                  {!isCorrect && (
                    <div className="text-slate-400">
                      Correct Answer: <span className="text-emerald-400 font-mono">{cAns}</span>
                    </div>
                  )}

                  <div className="bg-slate-900 p-3 rounded-lg text-slate-300 leading-relaxed text-[11px] border border-slate-800">
                    <span className="font-bold text-cyan-400">Explanation:</span> {q.explanation}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-slate-800">
            <button
              onClick={() => setQuizResult(null)}
              className="px-4 py-2 bg-slate-950 hover:bg-slate-800 text-slate-300 text-xs font-semibold rounded-xl border border-slate-800"
            >
              Take Another Quiz
            </button>

            <button
              onClick={() => setSection("practice")}
              className="px-5 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold rounded-xl"
            >
              Review Weak Topics in Practice Arena
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
