import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { STEMSubject, PracticeProblem, PracticeAttemptFeedback } from "../types";
import { Target, Sparkles, CheckCircle2, AlertTriangle, ArrowRight, Calculator, HelpCircle } from "lucide-react";

export const PracticeArena: React.FC = () => {
  const { topicMastery, updateMastery, setSection } = useApp();

  const [selectedSubject, setSelectedSubject] = useState<STEMSubject>("Aerospace Engineering");
  const [selectedTopic, setSelectedTopic] = useState("Lift and Drag");
  const [userCalculation, setUserCalculation] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  // Active Practice Problem State
  const problem: PracticeProblem = {
    id: "prob-1",
    subject: selectedSubject,
    topic: selectedTopic,
    question: `An aircraft flies at airspeed V = 120 m/s at altitude where air density ρ = 1.0 kg/m³. The wing planform area S = 25 m² and the current lift coefficient C_L = 0.5. Calculate the total aerodynamic lift force (L in Newtons).`,
    givenData: {
      Airspeed: "V = 120 m/s",
      "Air Density": "ρ = 1.0 kg/m³",
      "Wing Area": "S = 25 m²",
      "Lift Coefficient": "C_L = 0.5"
    },
    difficulty: "Medium",
    expectedUnits: "N",
    hint: "Use lift formula: L = 0.5 * ρ * V² * S * C_L"
  };

  const [feedback, setFeedback] = useState<PracticeAttemptFeedback | null>(null);

  const handleSubmitAttempt = () => {
    if (!userCalculation.trim()) return;
    setLoading(true);

    const val = parseFloat(userCalculation);
    // Correct L = 0.5 * 1.0 * (120)^2 * 25 * 0.5 = 0.5 * 14400 * 12.5 = 90,000 N
    const isCorrect = !isNaN(val) && Math.abs(val - 90000) < 500;

    setTimeout(() => {
      if (isCorrect) {
        setFeedback({
          userAttempt: userCalculation,
          isCorrect: true,
          correctApproach: "L = 0.5 * ρ * V² * S * C_L = 0.5 * 1.0 * (120)² * 25 * 0.5 = 90,000 N",
          finalAnswer: "90,000 N",
          similarProblemPrompt: "What would the lift force be if flight airspeed increased to 240 m/s?"
        });
        updateMastery(selectedTopic, 95);
      } else {
        setFeedback({
          userAttempt: userCalculation,
          isCorrect: false,
          whereReasoningWentWrong: "Make sure you square the airspeed (V² = 14,400) and multiply all factors together: 0.5 * 1.0 * 14400 * 25 * 0.5.",
          correctApproach: "1. Calculate dynamic pressure q = 0.5 * ρ * V² = 0.5 * 1.0 * 14,400 = 7,200 Pa.\n2. Multiply by wing area S: 7,200 * 25 = 180,000 N.\n3. Multiply by C_L (0.5): 180,000 * 0.5 = 90,000 N.",
          finalAnswer: "90,000 N",
          similarProblemPrompt: "Try calculating lift force with V = 100 m/s and C_L = 0.8."
        });
        updateMastery(selectedTopic, 65);
      }
      setSubmitted(true);
      setLoading(false);
    }, 600);
  };

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-4xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-2xl">
        <div>
          <h1 className="text-2xl font-extrabold text-white flex items-center gap-2.5">
            <Target className="w-6 h-6 text-cyan-400" />
            <span>AI Practice Arena</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Solve numerical and physical STEM problems with interactive calculations and step-by-step diagnostic feedback.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={selectedTopic}
            onChange={e => {
              setSelectedTopic(e.target.value);
              setSubmitted(false);
              setFeedback(null);
            }}
            className="bg-slate-950 border border-slate-800 text-xs text-white px-3 py-2 rounded-xl focus:outline-none"
          >
            {topicMastery.map(t => (
              <option key={t.topicName} value={t.topicName}>
                {t.topicName} ({t.score}%)
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Problem Canvas */}
      <div className="bg-slate-900 border border-slate-800 p-6 md:p-8 rounded-2xl space-y-6">
        <div className="flex items-center justify-between text-xs text-slate-400 pb-3 border-b border-slate-800">
          <span className="font-mono text-cyan-400 font-bold">{problem.subject}</span>
          <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px] font-mono uppercase">
            {problem.difficulty}
          </span>
        </div>

        <div className="space-y-4">
          <h2 className="text-base md:text-lg font-bold text-white leading-relaxed">{problem.question}</h2>

          {/* Given Data Block */}
          <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl space-y-2">
            <div className="text-xs font-bold text-slate-300">Given System Data:</div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
              {Object.entries(problem.givenData!).map(([key, val]) => (
                <div key={key} className="bg-slate-900 p-2 rounded border border-slate-800">
                  <span className="text-slate-400 text-[10px] block">{key}</span>
                  <span className="text-cyan-300 font-bold">{val}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Solution Input Scratchpad */}
          {!submitted && (
            <div className="space-y-3 pt-2">
              <label className="block text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Calculator className="w-4 h-4 text-cyan-400" />
                <span>Your Calculation / Numerical Answer (in {problem.expectedUnits}):</span>
              </label>

              <input
                type="text"
                value={userCalculation}
                onChange={e => setUserCalculation(e.target.value)}
                placeholder="e.g. 90000"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-white font-mono focus:outline-none focus:border-cyan-500"
                id="practice-answer-input"
              />

              <div className="flex items-center justify-between pt-2">
                <span className="text-[11px] text-slate-400 italic">Hint: {problem.hint}</span>
                <button
                  onClick={handleSubmitAttempt}
                  disabled={!userCalculation.trim() || loading}
                  className="px-6 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs rounded-xl shadow-md shadow-cyan-500/20 disabled:opacity-40"
                  id="submit-practice-btn"
                >
                  {loading ? "Checking Solution..." : "Submit Answer"}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Step-by-Step Diagnostic Feedback */}
        {submitted && feedback && (
          <div className="bg-slate-950 border border-slate-800 p-6 rounded-2xl space-y-5 animate-in fade-in">
            <div className="flex items-center gap-2">
              {feedback.isCorrect ? (
                <div className="text-emerald-400 font-bold text-sm flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5" />
                  <span>Correct Reasoning & Final Solution! (+150 XP)</span>
                </div>
              ) : (
                <div className="text-amber-400 font-bold text-sm flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5" />
                  <span>Calculation Diagnosis</span>
                </div>
              )}
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <span className="text-slate-400 font-bold">1. What You Attempted: </span>
                <span className="text-white font-mono">{feedback.userAttempt}</span>
              </div>

              {!feedback.isCorrect && (
                <div className="bg-rose-950/30 border border-rose-500/30 p-3 rounded-xl text-rose-200 leading-relaxed">
                  <span className="font-bold text-rose-400">2. Where Reasoning Went Wrong: </span>
                  {feedback.whereReasoningWentWrong}
                </div>
              )}

              <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-2">
                <div className="font-bold text-cyan-400">3. Correct Step-by-Step Approach:</div>
                <div className="text-slate-200 font-mono whitespace-pre-line leading-relaxed">
                  {feedback.correctApproach}
                </div>
              </div>

              <div>
                <span className="text-slate-400 font-bold">4. Final Answer: </span>
                <span className="text-emerald-400 font-mono font-bold text-sm">{feedback.finalAnswer}</span>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
              <button
                onClick={() => {
                  setSubmitted(false);
                  setUserCalculation("");
                  setFeedback(null);
                }}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-semibold rounded-xl border border-slate-800"
              >
                Try Next Practice Problem
              </button>

              <button
                onClick={() => setSection("aerospace-lab")}
                className="px-5 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold rounded-xl flex items-center gap-1.5"
              >
                <span>Simulate in Aerospace Lab</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
