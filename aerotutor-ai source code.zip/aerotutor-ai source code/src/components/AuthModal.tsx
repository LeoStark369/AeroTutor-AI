import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { STEMSubject } from "../types";
import { X, Rocket, Check, ArrowRight, UserCheck, Shield } from "lucide-react";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const { user, updateUser, setSection } = useApp();
  const [mode, setMode] = useState<"login" | "signup" | "onboarding" | "forgot">("onboarding");

  // Form State
  const [name, setName] = useState(user.name);
  const [email, setEmail] = useState(user.email);
  const [ageRange, setAgeRange] = useState(user.ageRange);
  const [educationLevel, setEducationLevel] = useState(user.educationLevel);
  const [country, setCountry] = useState(user.country);
  const [language, setLanguage] = useState(user.language);
  const [selectedSubjects, setSelectedSubjects] = useState<STEMSubject[]>(user.preferredSubjects);
  const [skillLevel, setSkillLevel] = useState(user.skillLevel);
  const [learningStyle, setLearningStyle] = useState(user.learningStyle);
  const [goalsInput, setGoalsInput] = useState(user.learningGoals.join(", "));

  if (!isOpen) return null;

  const subjectsList: STEMSubject[] = [
    "Aerospace Engineering",
    "Physics",
    "Mathematics",
    "Computer Science",
    "Engineering",
    "Chemistry",
    "Biology"
  ];

  const toggleSubject = (sub: STEMSubject) => {
    setSelectedSubjects(prev =>
      prev.includes(sub) ? prev.filter(s => s !== sub) : [...prev, sub]
    );
  };

  const handleSaveOnboarding = (skip: boolean = false) => {
    if (!skip) {
      updateUser({
        name: name || "Student Cadet",
        email: email || "cadet@aerotutor.ai",
        ageRange,
        educationLevel,
        country,
        language,
        preferredSubjects: selectedSubjects.length > 0 ? selectedSubjects : ["Aerospace Engineering", "Physics"],
        skillLevel,
        learningStyle,
        learningGoals: goalsInput ? goalsInput.split(",").map(g => g.trim()) : ["Master STEM concepts"]
      });
    }
    onClose();
    setSection("dashboard");
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto shadow-2xl p-6 text-slate-100 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1 text-slate-400 hover:text-white rounded-lg"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 flex items-center justify-center">
            <Rocket className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">
              {mode === "onboarding" ? "Customize Your AeroTutor AI Profile" : mode === "login" ? "Sign In to AeroTutor AI" : "Create Student Account"}
            </h2>
            <p className="text-xs text-slate-400">Personalize your STEM and Aerospace learning path</p>
          </div>
        </div>

        {mode === "onboarding" && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Full Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                  placeholder="e.g. Alex Vance"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Education Level</label>
                <select
                  value={educationLevel}
                  onChange={e => setEducationLevel(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                >
                  <option>High School</option>
                  <option>Undergraduate Engineering</option>
                  <option>Graduate / Master's</option>
                  <option>Self-Learner / Enthusiast</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Preferred Subjects (Flagship: Aerospace)</label>
              <div className="flex flex-wrap gap-2">
                {subjectsList.map(sub => {
                  const selected = selectedSubjects.includes(sub);
                  return (
                    <button
                      key={sub}
                      type="button"
                      onClick={() => toggleSubject(sub)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-all flex items-center gap-1.5 ${
                        selected
                          ? "bg-cyan-500/20 text-cyan-300 border-cyan-500/40"
                          : "bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700"
                      }`}
                    >
                      {selected && <Check className="w-3.5 h-3.5 text-cyan-400" />}
                      <span>{sub}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Current Skill Level</label>
                <select
                  value={skillLevel}
                  onChange={e => setSkillLevel(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                >
                  <option>Beginner</option>
                  <option>Intermediate</option>
                  <option>Advanced</option>
                  <option>Expert</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Preferred Learning Style</label>
                <select
                  value={learningStyle}
                  onChange={e => setLearningStyle(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                >
                  <option>Practical (Lab & Simulations)</option>
                  <option>Visual (Diagrams & Charts)</option>
                  <option>Socratic (Guided Questions)</option>
                  <option>Mathematical (Derivations)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Learning Goals (comma separated)</label>
              <input
                type="text"
                value={goalsInput}
                onChange={e => setGoalsInput(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                placeholder="e.g. Master Lift & Drag, Ace Orbital Mechanics"
              />
            </div>

            <div className="pt-4 flex items-center justify-between border-t border-slate-800">
              <button
                type="button"
                onClick={() => handleSaveOnboarding(true)}
                className="text-xs text-slate-400 hover:text-slate-200 underline"
              >
                Skip optional questions
              </button>

              <button
                type="button"
                onClick={() => handleSaveOnboarding(false)}
                className="px-6 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-md shadow-cyan-500/20"
                id="save-onboarding-btn"
              >
                <span>Save Profile & Start</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
