import React from "react";
import { useApp } from "../context/AppContext";
import { Eye, Volume2, Type, Keyboard, Check, Shield } from "lucide-react";

export const AccessibilitySettings: React.FC = () => {
  const { accessibility, updateAccessibility } = useApp();

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-4xl mx-auto">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-2">
        <h1 className="text-2xl font-extrabold text-white flex items-center gap-2.5">
          <Eye className="w-6 h-6 text-cyan-400" />
          <span>Accessibility & Visual Customization</span>
        </h1>
        <p className="text-xs text-slate-400">
          Tailor typography, color contrast, speech rate, and keyboard shortcuts for an accessible learning environment.
        </p>
      </div>

      {/* Settings Options */}
      <div className="bg-slate-900 border border-slate-800 p-6 md:p-8 rounded-2xl space-y-6">
        {/* Font Size */}
        <div className="space-y-2 pb-4 border-b border-slate-800">
          <label className="block text-xs font-bold text-white flex items-center gap-2">
            <Type className="w-4 h-4 text-cyan-400" />
            <span>Interface Font Size</span>
          </label>
          <div className="flex gap-2">
            {(["normal", "large", "extra-large"] as const).map(size => (
              <button
                key={size}
                onClick={() => updateAccessibility({ fontSize: size })}
                className={`px-4 py-2 rounded-xl text-xs font-bold capitalize border transition-all ${
                  accessibility.fontSize === size
                    ? "bg-cyan-500 text-slate-950 border-cyan-400"
                    : "bg-slate-950 text-slate-400 border-slate-800 hover:text-white"
                }`}
              >
                {size.replace("-", " ")}
              </button>
            ))}
          </div>
        </div>

        {/* High Contrast Mode */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div>
            <div className="text-xs font-bold text-white">High Contrast UI Mode</div>
            <div className="text-[11px] text-slate-400">Increases text contrast ratio for high readability</div>
          </div>
          <button
            onClick={() => updateAccessibility({ highContrast: !accessibility.highContrast })}
            className={`w-12 h-6 rounded-full transition-colors p-1 flex items-center ${
              accessibility.highContrast ? "bg-cyan-500 justify-end" : "bg-slate-950 justify-start"
            }`}
          >
            <div className="w-4 h-4 rounded-full bg-slate-900" />
          </button>
        </div>

        {/* Dyslexic Friendly Font */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div>
            <div className="text-xs font-bold text-white">Dyslexia-Friendly Font</div>
            <div className="text-[11px] text-slate-400">Switch to open-dyslexic style lettering spacing</div>
          </div>
          <button
            onClick={() => updateAccessibility({ dyslexicFont: !accessibility.dyslexicFont })}
            className={`w-12 h-6 rounded-full transition-colors p-1 flex items-center ${
              accessibility.dyslexicFont ? "bg-cyan-500 justify-end" : "bg-slate-950 justify-start"
            }`}
          >
            <div className="w-4 h-4 rounded-full bg-slate-900" />
          </button>
        </div>

        {/* Keyboard Shortcuts Reference */}
        <div className="space-y-3 pt-2">
          <h3 className="text-xs font-bold text-white flex items-center gap-2">
            <Keyboard className="w-4 h-4 text-cyan-400" />
            <span>Global Keyboard Shortcuts</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
            {[
              { key: "Alt + D", desc: "Open Student Dashboard" },
              { key: "Alt + T", desc: "Open AI Tutor Workspace" },
              { key: "Alt + L", desc: "Open Aerospace Flagship Lab" },
              { key: "Alt + Q", desc: "Generate STEM Quiz" },
              { key: "Alt + P", desc: "Open Practice Arena" },
              { key: "Alt + V", desc: "Launch Voice Tutor Mode" }
            ].map((sc, idx) => (
              <div key={idx} className="bg-slate-950 border border-slate-800 p-3 rounded-xl flex justify-between items-center">
                <span className="text-slate-400 text-[11px]">{sc.desc}</span>
                <span className="px-2 py-0.5 bg-slate-900 border border-slate-700 text-cyan-400 rounded font-bold">
                  {sc.key}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
