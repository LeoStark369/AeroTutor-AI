import React, { useState, useRef, useEffect } from "react";
import { useApp } from "../context/AppContext";
import { TutorMode } from "../types";
import {
  Send,
  Bot,
  User,
  Sparkles,
  Paperclip,
  Mic,
  Volume2,
  BookOpen,
  HelpCircle,
  FileText,
  RotateCcw,
  Check,
  Lightbulb,
  Cpu,
  GraduationCap,
  Layers,
  Image as ImageIcon
} from "lucide-react";

export const AITutor: React.FC = () => {
  const {
    activeChat,
    createChatSession,
    addChatMessage,
    tutorMode,
    setTutorMode,
    activeDocument,
    documents,
    setSection,
    recordQuizResult
  } = useApp();

  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [useDocContext, setUseDocContext] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const modes: { mode: TutorMode; label: string; desc: string }[] = [
    { mode: "Beginner", label: "Beginner", desc: "Intuitive analogies & plain terms" },
    { mode: "Student", label: "Student", desc: "Standard school/undergrad level" },
    { mode: "Advanced", label: "Advanced", desc: "Deep math, derivations & rigor" },
    { mode: "Engineering", label: "Engineering", desc: "Technical equations, design assumptions & applications" },
    { mode: "Exam Mode", label: "Exam Mode", desc: "Problem-solving techniques & test prep" },
    { mode: "Socratic Mode", label: "Socratic", desc: "Asks guiding questions (no direct spoiler answers)" }
  ];

  const quickActions = [
    "Explain simpler",
    "Give an example",
    "Show equations",
    "Give analogy",
    "Test me",
    "Give practice",
    "Summarize",
    "Read aloud"
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [activeChat?.messages, loading]);

  const handleSend = async (textToSend?: string) => {
    const query = (textToSend || input).trim();
    if (!query || loading) return;

    let chatId = activeChat?.id;
    if (!chatId) {
      chatId = createChatSession("Aerospace & STEM Discussion", "Aerospace Engineering", activeDocument?.id);
    }

    addChatMessage(chatId, "user", query, tutorMode);
    setInput("");
    setLoading(true);

    try {
      const docCtx = useDocContext && activeDocument ? activeDocument.content : "";
      const history = (activeChat?.messages || []).map(m => ({ role: m.role, content: m.content }));

      const res = await fetch("/api/gemini/tutor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: query,
          tutorMode,
          documentContext: docCtx,
          history,
          image: selectedImage
        })
      });

      const data = await res.json();
      if (data.error) {
        addChatMessage(chatId, "assistant", `⚠️ AI response error: ${data.error}`, tutorMode);
      } else {
        addChatMessage(chatId, "assistant", data.response, tutorMode);
      }
    } catch (err: any) {
      addChatMessage(
        chatId,
        "assistant",
        "AI service is temporarily unavailable. Please verify your connection or Gemini API key.",
        tutorMode
      );
    } finally {
      setLoading(false);
      setSelectedImage(null);
    }
  };

  const handleQuickAction = (action: string) => {
    if (action === "Test me" || action === "Give practice") {
      setSection("quiz");
      return;
    }
    if (action === "Read aloud") {
      const lastMsg = activeChat?.messages.filter(m => m.role === "assistant").slice(-1)[0];
      if (lastMsg) speakText(lastMsg.content);
      return;
    }
    handleSend(`${action} for the previous response.`);
  };

  const speakText = (text: string) => {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      const clean = text.replace(/[#*`]/g, "");
      const utterance = new SpeechSynthesisUtterance(clean.slice(0, 400));
      utterance.rate = 1.0;
      window.speechSynthesis.speak(utterance);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="h-[calc(100vh-4rem)] flex flex-col bg-slate-950 text-slate-100">
      {/* Top Controls Header */}
      <div className="bg-slate-900 border-b border-slate-800 p-3 md:px-6 flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-2 overflow-x-auto scrollbar-none py-1">
          <span className="text-[11px] font-mono text-slate-400 font-semibold uppercase tracking-wider shrink-0">
            Tutor Mode:
          </span>
          {modes.map(m => (
            <button
              key={m.mode}
              onClick={() => setTutorMode(m.mode)}
              title={m.desc}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all border ${
                tutorMode === m.mode
                  ? "bg-cyan-500/20 text-cyan-300 border-cyan-500/40 shadow-sm"
                  : "bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700"
              }`}
            >
              {m.label}
            </button>
          ))}
        </div>

        {activeDocument && (
          <div className="flex items-center gap-2 bg-slate-950 border border-slate-800 px-3 py-1 rounded-xl text-xs">
            <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-slate-300 truncate max-w-[150px]">{activeDocument.title}</span>
            <input
              type="checkbox"
              id="doc-context-checkbox"
              checked={useDocContext}
              onChange={e => setUseDocContext(e.target.checked)}
              className="accent-cyan-400 rounded cursor-pointer"
            />
            <label htmlFor="doc-context-checkbox" className="text-[10px] text-slate-400 cursor-pointer">
              Cite Doc
            </label>
          </div>
        )}
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
        {!activeChat || activeChat.messages.length === 0 ? (
          <div className="max-w-2xl mx-auto text-center py-12 space-y-6">
            <div className="w-16 h-16 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center mx-auto shadow-lg shadow-cyan-500/10">
              <Bot className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <h2 className="text-2xl font-extrabold text-white">Ask AeroTutor AI Anything</h2>
              <p className="text-slate-400 text-xs md:text-sm max-w-md mx-auto">
                Select your preferred Tutor Mode above (Engineering, Socratic, Exam, etc.), upload material, or try a sample STEM prompt.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-left">
              {[
                "Why does increasing the angle of attack affect aerodynamic lift?",
                "How do you derive orbital velocity v = sqrt(GM/r)?",
                "Explain boundary layer stall with intuitive analogies.",
                "What is the difference between turbojet and turbofan engines?"
              ].map((sample, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSend(sample)}
                  className="bg-slate-900 border border-slate-800 hover:border-cyan-500/40 p-3.5 rounded-xl text-xs text-slate-300 hover:text-white transition-all text-left font-medium"
                >
                  "{sample}"
                </button>
              ))}
            </div>
          </div>
        ) : (
          activeChat.messages.map((msg, i) => (
            <div
              key={msg.id || i}
              className={`flex items-start gap-3 ${msg.role === "user" ? "flex-row-reverse" : ""}`}
            >
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold shrink-0 ${
                  msg.role === "user"
                    ? "bg-cyan-500 text-slate-950"
                    : "bg-slate-900 border border-slate-800 text-cyan-400"
                }`}
              >
                {msg.role === "user" ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              <div className={`space-y-2 max-w-3xl ${msg.role === "user" ? "items-end text-right" : "text-left"}`}>
                <div className="flex items-center gap-2 text-[10px] text-slate-400">
                  <span>{msg.role === "user" ? "You" : "AeroTutor AI"}</span>
                  {msg.mode && (
                    <span className="px-1.5 py-0.2 rounded bg-cyan-500/10 text-cyan-300 font-mono border border-cyan-500/20">
                      {msg.mode}
                    </span>
                  )}
                  <span>{msg.timestamp}</span>
                </div>

                <div
                  className={`p-4 rounded-2xl text-xs md:text-sm leading-relaxed whitespace-pre-wrap font-sans ${
                    msg.role === "user"
                      ? "bg-cyan-600 text-white rounded-tr-none shadow-md shadow-cyan-900/20"
                      : "bg-slate-900 border border-slate-800/90 text-slate-200 rounded-tl-none shadow-lg"
                  }`}
                >
                  {msg.content}
                </div>

                {msg.role === "assistant" && (
                  <div className="flex items-center gap-2 pt-1">
                    <button
                      onClick={() => speakText(msg.content)}
                      className="text-[10px] text-slate-400 hover:text-cyan-400 flex items-center gap-1"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                      <span>Read Aloud</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))
        )}

        {loading && (
          <div className="flex items-center gap-3 text-cyan-400 text-xs py-3">
            <Bot className="w-5 h-5 animate-spin" />
            <span className="font-mono">AeroTutor AI is synthesizing response...</span>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Actions Bar */}
      <div className="bg-slate-900/80 border-t border-slate-800 p-2 overflow-x-auto scrollbar-none flex items-center gap-1.5">
        <span className="text-[10px] font-mono text-slate-400 px-2 font-semibold uppercase">Quick:</span>
        {quickActions.map(action => (
          <button
            key={action}
            onClick={() => handleQuickAction(action)}
            className="px-2.5 py-1 bg-slate-950 hover:bg-slate-800 text-slate-300 border border-slate-800 hover:border-cyan-500/30 rounded-lg text-xs font-medium whitespace-nowrap transition-all"
          >
            {action}
          </button>
        ))}
      </div>

      {/* Input Box */}
      <div className="p-3 md:p-4 bg-slate-900 border-t border-slate-800">
        {selectedImage && (
          <div className="mb-2 flex items-center gap-2 bg-slate-950 p-2 rounded-xl border border-slate-800 w-fit">
            <img src={selectedImage} alt="Attachment" className="w-10 h-10 object-cover rounded-lg" />
            <button
              onClick={() => setSelectedImage(null)}
              className="text-xs text-rose-400 hover:text-rose-300 font-bold px-2"
            >
              Remove
            </button>
          </div>
        )}

        <div className="flex items-center gap-2 bg-slate-950 border border-slate-800 rounded-2xl p-2 focus-within:border-cyan-500/50 transition-all">
          <label className="p-2 text-slate-400 hover:text-cyan-400 cursor-pointer rounded-xl hover:bg-slate-900">
            <ImageIcon className="w-4 h-4" />
            <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
          </label>

          <button
            onClick={() => setSection("voice")}
            className="p-2 text-slate-400 hover:text-cyan-400 rounded-xl hover:bg-slate-900"
            title="Voice Tutor Mode"
          >
            <Mic className="w-4 h-4" />
          </button>

          <input
            type="text"
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && handleSend()}
            placeholder={`Ask AeroTutor AI (${tutorMode} mode)...`}
            className="flex-1 bg-transparent text-xs md:text-sm text-white focus:outline-none px-2"
            id="tutor-chat-input"
          />

          <button
            onClick={() => handleSend()}
            disabled={!input.trim() || loading}
            className="p-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold rounded-xl disabled:opacity-30 transition-all shadow-md shadow-cyan-500/20"
            id="tutor-send-btn"
          >
            <Send className="w-4 h-4 stroke-[2.5]" />
          </button>
        </div>
      </div>
    </div>
  );
};
