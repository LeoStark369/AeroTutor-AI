import React from "react";
import { useApp } from "../context/AppContext";
import {
  BarChart2,
  TrendingUp,
  Award,
  AlertCircle,
  CheckCircle2,
  Calendar,
  Sparkles,
  ArrowRight
} from "lucide-react";

export const Analytics: React.FC = () => {
  const { user, topicMastery, quizResults, setSection } = useApp();

  const sortedMastery = [...topicMastery].sort((a, b) => b.score - a.score);

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-2xl">
        <div>
          <h1 className="text-2xl font-extrabold text-white flex items-center gap-2.5">
            <BarChart2 className="w-6 h-6 text-cyan-400" />
            <span>Learning Intelligence & Analytics</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Comprehensive diagnostic analysis of your STEM concept mastery, quiz accuracy, and study streaks.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-slate-950 border border-slate-800 px-4 py-2 rounded-xl text-xs font-mono">
            <span className="text-slate-400">Total XP: </span>
            <span className="text-cyan-400 font-bold">{user.totalXP.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Grid of Topic Mastery Bars */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
          <h2 className="text-base font-bold text-white flex items-center justify-between">
            <span>Concept Mastery Distribution</span>
            <span className="text-xs font-mono text-cyan-400">{topicMastery.length} Concepts Tracked</span>
          </h2>

          <div className="space-y-4">
            {sortedMastery.map((item, idx) => (
              <div key={idx} className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-200 font-medium">{item.topicName}</span>
                  <span className="font-mono font-bold text-cyan-400">{item.score}%</span>
                </div>
                <div className="w-full bg-slate-950 h-2.5 rounded-full border border-slate-800 overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all ${
                      item.score >= 80 ? "bg-emerald-400" : item.score >= 60 ? "bg-cyan-400" : "bg-amber-400"
                    }`}
                    style={{ width: `${item.score}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* History Log & AI Intelligence Suggestions */}
        <div className="space-y-8">
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span>AI Diagnostic Recommendations</span>
            </h2>

            <div className="space-y-3">
              <div className="bg-slate-950 border border-amber-500/30 p-4 rounded-xl space-y-2 text-xs">
                <div className="flex items-center gap-2 font-bold text-amber-400">
                  <AlertCircle className="w-4 h-4" />
                  <span>Weakness Detected: Vectors & Component Resolution</span>
                </div>
                <p className="text-slate-400 leading-relaxed">
                  Your quiz accuracy on vector resolution drops by 30% when trigonometry calculations are involved.
                </p>
                <button
                  onClick={() => setSection("practice")}
                  className="mt-2 px-3 py-1.5 bg-amber-500 text-slate-950 font-bold rounded-lg"
                >
                  Start Practice Arena Focus
                </button>
              </div>

              <div className="bg-slate-950 border border-emerald-500/30 p-4 rounded-xl space-y-2 text-xs">
                <div className="flex items-center gap-2 font-bold text-emerald-400">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Mastery Milestone: Aerodynamic Lift & Drag</span>
                </div>
                <p className="text-slate-400 leading-relaxed">
                  You scored 92% on Bernoulli's principles. Ready for advanced compressible flow.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
            <h2 className="text-base font-bold text-white flex items-center justify-between">
              <span>Recent Quiz History</span>
              <span className="text-xs text-slate-400">{quizResults.length} Completed</span>
            </h2>

            <div className="space-y-2">
              {quizResults.map((q, idx) => (
                <div key={idx} className="bg-slate-950 border border-slate-800 p-3 rounded-xl flex items-center justify-between text-xs">
                  <div>
                    <div className="font-bold text-white">{q.quizTitle}</div>
                    <div className="text-[10px] text-slate-400">{q.date}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-mono font-bold text-cyan-400">{q.accuracy}%</div>
                    <div className="text-[10px] text-slate-400">{q.score}/{q.total} Correct</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
