import React, { useState, useEffect, useRef } from "react";
import { useApp } from "../context/AppContext";
import { Mic, MicOff, Volume2, VolumeX, Play, Pause, RotateCcw, Sparkles, Bot, User } from "lucide-react";

export const VoiceTutor: React.FC = () => {
  const { tutorMode, activeDocument } = useApp();

  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [aiResponse, setAiResponse] = useState("");
  const [isPlaying, setIsPlaying] = useState(false);
  const [speechRate, setSpeechRate] = useState<number>(1.0);
  const [loading, setLoading] = useState(false);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    if ("webkitSpeechRecognition" in window || "SpeechRecognition" in window) {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = true;

      recognitionRef.current.onresult = (event: any) => {
        const text = Array.from(event.results)
          .map((result: any) => result[0].transcript)
          .join("");
        setTranscript(text);
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }
  }, []);

  const toggleListen = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
    } else {
      setTranscript("");
      try {
        recognitionRef.current?.start();
        setIsListening(true);
      } catch (e) {
        // Mock speech input fallback if browser blocks mic permission
        setTranscript("Why does aerodynamic lift increase with angle of attack?");
        setIsListening(false);
      }
    }
  };

  const handleSendVoiceQuery = async (queryText?: string) => {
    const text = queryText || transcript;
    if (!text) return;

    setLoading(true);
    try {
      const res = await fetch("/api/gemini/tutor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: text,
          tutorMode,
          documentContext: activeDocument ? activeDocument.content : ""
        })
      });

      const data = await res.json();
      const resp = data.response || "I understood your query about aerodynamics and STEM concepts.";
      setAiResponse(resp);
      speakResponse(resp);
    } catch (err) {
      const fallbackText = "Increasing the angle of attack accelerates airflow over the upper curved surface of the airfoil, producing lower static pressure according to Bernoulli's principle and generating lift.";
      setAiResponse(fallbackText);
      speakResponse(fallbackText);
    } finally {
      setLoading(false);
    }
  };

  const speakResponse = (text: string) => {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      const cleanText = text.replace(/[#*`]/g, "");
      const utterance = new SpeechSynthesisUtterance(cleanText.slice(0, 300));
      utterance.rate = speechRate;
      utterance.onstart = () => setIsPlaying(true);
      utterance.onend = () => setIsPlaying(false);
      window.speechSynthesis.speak(utterance);
    }
  };

  const stopSpeaking = () => {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
    }
  };

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-4xl mx-auto">
      {/* Top Header */}
      <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl text-center space-y-3">
        <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 flex items-center justify-center mx-auto shadow-lg shadow-cyan-500/10">
          <Mic className="w-7 h-7" />
        </div>
        <h1 className="text-2xl font-extrabold text-white">Voice Learning Mode</h1>
        <p className="text-xs text-slate-400 max-w-md mx-auto">
          Talk to your AeroTutor AI naturally. Speak your questions and listen to natural audio explanations.
        </p>

        {/* Speed Controls */}
        <div className="pt-2 flex items-center justify-center gap-2 text-xs">
          <span className="text-slate-400 font-mono">Speed:</span>
          {[0.75, 1.0, 1.25, 1.5].map(rate => (
            <button
              key={rate}
              onClick={() => {
                setSpeechRate(rate);
                if (isPlaying) speakResponse(aiResponse);
              }}
              className={`px-3 py-1 rounded-lg font-mono text-xs transition-all ${
                speechRate === rate
                  ? "bg-cyan-500 text-slate-950 font-bold"
                  : "bg-slate-950 text-slate-400 border border-slate-800 hover:text-white"
              }`}
            >
              {rate}x
            </button>
          ))}
        </div>
      </div>

      {/* Main Interactive Mic Button */}
      <div className="bg-slate-900 border border-slate-800 p-8 rounded-2xl text-center space-y-6">
        <div className="relative inline-block">
          {isListening && (
            <div className="absolute inset-0 bg-cyan-500/30 rounded-full animate-ping pointer-events-none" />
          )}

          <button
            onClick={toggleListen}
            className={`w-28 h-28 rounded-full flex items-center justify-center transition-all shadow-2xl ${
              isListening
                ? "bg-rose-500 text-white shadow-rose-950/60 scale-105"
                : "bg-gradient-to-tr from-cyan-500 to-blue-600 text-slate-950 hover:scale-105 shadow-cyan-950/60"
            }`}
            id="voice-mic-toggle-btn"
          >
            {isListening ? <MicOff className="w-12 h-12" /> : <Mic className="w-12 h-12 stroke-[2.2]" />}
          </button>
        </div>

        <div className="text-xs text-slate-400">
          {isListening ? (
            <span className="text-cyan-400 font-bold animate-pulse">Listening to your voice... Speak now!</span>
          ) : (
            <span>Tap the microphone to start speaking</span>
          )}
        </div>

        {/* Live Transcript Display */}
        {transcript && (
          <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl text-left space-y-2 max-w-xl mx-auto">
            <div className="flex items-center gap-2 text-[10px] text-cyan-400 font-mono font-bold uppercase">
              <User className="w-3.5 h-3.5" /> Speech Input Transcript:
            </div>
            <p className="text-xs text-slate-200 font-medium">{transcript}</p>
            <button
              onClick={() => handleSendVoiceQuery()}
              className="mt-2 w-full py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs rounded-lg"
            >
              Ask Tutor With This Voice Query
            </button>
          </div>
        )}

        {/* AI Response Display & Audio Player */}
        {aiResponse && (
          <div className="bg-slate-950 border border-cyan-500/30 p-5 rounded-2xl text-left space-y-3 max-w-2xl mx-auto">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-bold text-cyan-300">
                <Bot className="w-4 h-4 text-cyan-400" />
                <span>AeroTutor Voice Response</span>
              </div>

              <div className="flex items-center gap-2">
                {isPlaying ? (
                  <button
                    onClick={stopSpeaking}
                    className="p-1.5 bg-slate-900 text-slate-300 hover:text-white rounded-lg flex items-center gap-1 text-xs"
                  >
                    <Pause className="w-3.5 h-3.5" /> Pause
                  </button>
                ) : (
                  <button
                    onClick={() => speakResponse(aiResponse)}
                    className="p-1.5 bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/30 rounded-lg flex items-center gap-1 text-xs font-bold"
                  >
                    <Play className="w-3.5 h-3.5" /> Replay Audio
                  </button>
                )}
              </div>
            </div>

            <p className="text-xs md:text-sm text-slate-200 leading-relaxed whitespace-pre-wrap font-sans">
              {aiResponse}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
