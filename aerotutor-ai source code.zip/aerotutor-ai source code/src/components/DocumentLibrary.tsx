import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { STEMSubject } from "../types";
import {
  BookOpen,
  Upload,
  FileText,
  Plus,
  ArrowRight,
  Sparkles,
  CheckCircle2,
  Trash2,
  BookMarked,
  Search
} from "lucide-react";

export const DocumentLibrary: React.FC = () => {
  const { documents, uploadDocument, setActiveDocumentId, activeDocument, setSection } = useApp();
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [title, setTitle] = useState("");
  const [subject, setSubject] = useState<STEMSubject>("Aerospace Engineering");
  const [content, setContent] = useState("");
  const [analyzing, setAnalyzing] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  const handleUploadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !content) return;

    setAnalyzing(true);
    try {
      const res = await fetch("/api/gemini/analyze-doc", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, text: content })
      });
      const data = await res.json();

      const docId = uploadDocument({
        title,
        subject,
        content,
        summary30s: data.summary30s,
        summary5m: data.summary5m,
        summaryDetailed: data.summaryDetailed,
        chapters: data.chapters,
        keyConcepts: data.keyConcepts,
        formulas: data.formulas,
        keyTerms: data.keyTerms,
        examRevision: data.examRevision
      });

      setShowUploadModal(false);
      setTitle("");
      setContent("");
      setActiveDocumentId(docId);
      setSection("summary");
    } catch (err) {
      console.error(err);
      uploadDocument({ title, subject, content });
      setShowUploadModal(false);
    } finally {
      setAnalyzing(false);
    }
  };

  const filteredDocs = documents.filter(
    d =>
      d.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      d.subject.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-7xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-white flex items-center gap-2.5">
            <BookOpen className="w-7 h-7 text-cyan-400" />
            <span>Smart Textbook & PDF Library</span>
          </h1>
          <p className="text-xs md:text-sm text-slate-400 mt-1">
            Upload STEM materials and transform them into interactive AI courses, formula sheets, and practice quizzes.
          </p>
        </div>

        <button
          onClick={() => setShowUploadModal(true)}
          className="px-5 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-2 shadow-lg shadow-cyan-500/20"
          id="upload-doc-modal-btn"
        >
          <Upload className="w-4 h-4" />
          <span>Upload Document / PDF</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="relative max-w-md">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
          placeholder="Search textbooks, subjects, or notes..."
          className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
        />
      </div>

      {/* Document Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredDocs.map(doc => {
          const isActive = activeDocument?.id === doc.id;
          return (
            <div
              key={doc.id}
              className={`bg-slate-900 border rounded-2xl p-6 space-y-4 flex flex-col justify-between transition-all ${
                isActive
                  ? "border-cyan-500/50 shadow-lg shadow-cyan-950/40 ring-1 ring-cyan-500/30"
                  : "border-slate-800 hover:border-slate-700"
              }`}
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                    {doc.subject}
                  </span>
                  {doc.isDemo && (
                    <span className="text-[9px] font-mono uppercase text-slate-400 bg-slate-800 px-2 py-0.5 rounded">
                      Demo Content
                    </span>
                  )}
                </div>

                <h3 className="text-base font-bold text-white line-clamp-2">{doc.title}</h3>
                <p className="text-xs text-slate-400 line-clamp-3 leading-relaxed">
                  {doc.summary30s || doc.content.slice(0, 150)}
                </p>

                {doc.chapters && (
                  <div className="pt-1 flex flex-wrap gap-1">
                    {doc.chapters.slice(0, 3).map((ch, idx) => (
                      <span key={idx} className="text-[10px] bg-slate-950 text-slate-300 px-2 py-0.5 rounded border border-slate-800 truncate max-w-[140px]">
                        {ch}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              <div className="pt-4 border-t border-slate-800 space-y-3">
                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span>Progress</span>
                  <span className="font-semibold text-white">{doc.progress}%</span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setActiveDocumentId(doc.id);
                      setSection("summary");
                    }}
                    className="flex-1 py-2 bg-slate-950 hover:bg-slate-800 text-slate-200 text-xs font-semibold rounded-xl border border-slate-800 transition-all text-center"
                  >
                    Summary & Formulas
                  </button>

                  <button
                    onClick={() => {
                      setActiveDocumentId(doc.id);
                      setSection("tutor");
                    }}
                    className="flex-1 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold rounded-xl transition-all text-center flex items-center justify-center gap-1"
                    id={`ask-textbook-btn-${doc.id}`}
                  >
                    <BookMarked className="w-3.5 h-3.5" />
                    <span>Ask Textbook</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Upload Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-xl p-6 text-slate-100 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Upload className="w-5 h-5 text-cyan-400" />
                <span>Upload Educational Material</span>
              </h2>
              <button onClick={() => setShowUploadModal(false)} className="text-slate-400 hover:text-white">
                ✕
              </button>
            </div>

            <form onSubmit={handleUploadSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Document Title</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="e.g. Flight Dynamics & Compressible Flow Notes"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Subject</label>
                <select
                  value={subject}
                  onChange={e => setSubject(e.target.value as STEMSubject)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                >
                  <option>Aerospace Engineering</option>
                  <option>Physics</option>
                  <option>Mathematics</option>
                  <option>Computer Science</option>
                  <option>Engineering</option>
                  <option>Chemistry</option>
                  <option>Biology</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Paste Text / Notes / Chapter Content</label>
                <textarea
                  required
                  rows={6}
                  value={content}
                  onChange={e => setContent(e.target.value)}
                  placeholder="Paste your lecture notes, textbook excerpt, formulas, or study guides here..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="px-4 py-2 bg-slate-950 hover:bg-slate-800 text-slate-400 text-xs font-semibold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={analyzing}
                  className="px-6 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-md shadow-cyan-500/20 disabled:opacity-50"
                  id="process-document-btn"
                >
                  {analyzing ? (
                    <>
                      <Sparkles className="w-4 h-4 animate-spin" />
                      <span>Analyzing Document...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>Process & Analyze</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
