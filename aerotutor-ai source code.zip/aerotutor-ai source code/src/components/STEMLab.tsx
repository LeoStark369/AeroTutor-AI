import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { FlaskConical, Cpu, Binary, Layers, Play, RotateCcw, Zap } from "lucide-react";

export const STEMLab: React.FC = () => {
  const { addXP } = useApp();
  const [activeTab, setActiveTab] = useState<"cs" | "circuits" | "vectors" | "periodic">("cs");

  // CS Sorting Visualizer State
  const [array, setArray] = useState<number[]>([45, 12, 88, 32, 67, 21, 95, 54, 30, 75]);
  const [sorting, setSorting] = useState(false);

  // Circuits State
  const [voltage, setVoltage] = useState(12); // Volts
  const [resistance, setResistance] = useState(4); // Ohms
  const current = (voltage / resistance).toFixed(2); // Amps
  const power = (voltage * (voltage / resistance)).toFixed(2); // Watts

  // Vectors State
  const [vx, setVx] = useState(4);
  const [vy, setVy] = useState(3);
  const mag = Math.sqrt(vx * vx + vy * vy).toFixed(2);
  const angle = ((Math.atan2(vy, vx) * 180) / Math.PI).toFixed(1);

  const runBubbleSort = async () => {
    setSorting(true);
    let arr = [...array];
    for (let i = 0; i < arr.length; i++) {
      for (let j = 0; j < arr.length - i - 1; j++) {
        if (arr[j] > arr[j + 1]) {
          let temp = arr[j];
          arr[j] = arr[j + 1];
          arr[j + 1] = temp;
          setArray([...arr]);
          await new Promise(r => setTimeout(r, 120));
        }
      }
    }
    setSorting(false);
    addXP(100);
  };

  const resetArray = () => {
    setArray(Array.from({ length: 10 }, () => Math.floor(Math.random() * 85) + 10));
  };

  const elements = [
    { symbol: "H", name: "Hydrogen", number: 1, mass: "1.008", category: "Nonmetal" },
    { symbol: "He", name: "Helium", number: 2, mass: "4.0026", category: "Noble Gas" },
    { symbol: "Li", name: "Lithium", number: 3, mass: "6.94", category: "Alkali Metal" },
    { symbol: "Be", name: "Beryllium", number: 4, mass: "9.0122", category: "Alkaline Earth" },
    { symbol: "B", name: "Boron", number: 5, mass: "10.81", category: "Metalloid" },
    { symbol: "C", name: "Carbon", number: 6, mass: "12.011", category: "Nonmetal" },
    { symbol: "N", name: "Nitrogen", number: 7, mass: "14.007", category: "Nonmetal" },
    { symbol: "O", name: "Oxygen", number: 8, mass: "15.999", category: "Nonmetal" },
    { symbol: "F", name: "Fluorine", number: 9, mass: "18.998", category: "Halogen" },
    { symbol: "Ne", name: "Neon", number: 10, mass: "20.180", category: "Noble Gas" }
  ];

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-6xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-2xl">
        <div>
          <h1 className="text-2xl font-extrabold text-white flex items-center gap-2.5">
            <FlaskConical className="w-6 h-6 text-cyan-400" />
            <span>Interactive STEM Laboratory</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            General interactive simulations for Physics, Mathematics, Computer Science algorithms, and Chemistry.
          </p>
        </div>

        {/* Tab Buttons */}
        <div className="flex overflow-x-auto scrollbar-none gap-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800">
          {[
            { id: "cs", label: "CS Algorithms", icon: Binary },
            { id: "circuits", label: "Ohm's Circuits", icon: Zap },
            { id: "vectors", label: "2D Vectors", icon: Layers },
            { id: "periodic", label: "Periodic Table", icon: FlaskConical }
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                  isActive
                    ? "bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* CS Sorting Workspace */}
      {activeTab === "cs" && (
        <div className="bg-slate-900 border border-slate-800 p-6 md:p-8 rounded-2xl space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Binary className="w-4 h-4 text-cyan-400" />
              <span>Sorting Algorithm Step Visualizer (Bubble Sort)</span>
            </h2>

            <div className="flex items-center gap-2">
              <button
                onClick={resetArray}
                disabled={sorting}
                className="px-3 py-1.5 bg-slate-950 text-slate-300 text-xs font-semibold rounded-lg border border-slate-800"
              >
                Randomize Array
              </button>
              <button
                onClick={runBubbleSort}
                disabled={sorting}
                className="px-4 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold rounded-lg flex items-center gap-1.5"
                id="run-sorting-btn"
              >
                <Play className="w-3.5 h-3.5 fill-slate-950" />
                <span>{sorting ? "Sorting..." : "Run Sort"}</span>
              </button>
            </div>
          </div>

          <div className="bg-slate-950 border border-slate-800 p-6 rounded-2xl h-64 flex items-end justify-center gap-3">
            {array.map((val, idx) => (
              <div key={idx} className="flex flex-col items-center gap-1 flex-1 max-w-[40px]">
                <span className="text-[10px] font-mono text-cyan-400 font-bold">{val}</span>
                <div
                  className="w-full bg-gradient-to-t from-cyan-600 to-blue-400 rounded-t-lg transition-all duration-150"
                  style={{ height: `${val * 2}px` }}
                />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Circuits Workspace */}
      {activeTab === "circuits" && (
        <div className="bg-slate-900 border border-slate-800 p-6 md:p-8 rounded-2xl space-y-6">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Zap className="w-4 h-4 text-cyan-400" />
            <span>Electrical Circuit Simulator (Ohm's Law: V = I × R)</span>
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-xs text-slate-300 mb-1">
                  <span>DC Source Voltage (V):</span>
                  <span className="font-mono font-bold text-cyan-400">{voltage} Volts</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="48"
                  value={voltage}
                  onChange={e => setVoltage(Number(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs text-slate-300 mb-1">
                  <span>Resistor Value (R):</span>
                  <span className="font-mono font-bold text-cyan-400">{resistance} Ω</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="20"
                  value={resistance}
                  onChange={e => setResistance(Number(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>
            </div>

            <div className="bg-slate-950 border border-slate-800 p-6 rounded-2xl space-y-3 font-mono text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Current (I = V/R):</span>
                <span className="text-emerald-400 font-bold text-sm">{current} Amperes</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Power Dissipated (P = V × I):</span>
                <span className="text-amber-400 font-bold text-sm">{power} Watts</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Vectors Workspace */}
      {activeTab === "vectors" && (
        <div className="bg-slate-900 border border-slate-800 p-6 md:p-8 rounded-2xl space-y-6">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Layers className="w-4 h-4 text-cyan-400" />
            <span>2D Vector Resolution & Components</span>
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-xs text-slate-300 mb-1">
                  <span>X Component (Vx):</span>
                  <span className="font-mono font-bold text-cyan-400">{vx}</span>
                </div>
                <input
                  type="range"
                  min="-10"
                  max="10"
                  value={vx}
                  onChange={e => setVx(Number(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs text-slate-300 mb-1">
                  <span>Y Component (Vy):</span>
                  <span className="font-mono font-bold text-cyan-400">{vy}</span>
                </div>
                <input
                  type="range"
                  min="-10"
                  max="10"
                  value={vy}
                  onChange={e => setVy(Number(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>
            </div>

            <div className="bg-slate-950 border border-slate-800 p-6 rounded-2xl space-y-3 font-mono text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Magnitude |V|:</span>
                <span className="text-cyan-300 font-bold text-sm">{mag}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Angle θ:</span>
                <span className="text-emerald-400 font-bold text-sm">{angle}°</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Periodic Table */}
      {activeTab === "periodic" && (
        <div className="bg-slate-900 border border-slate-800 p-6 md:p-8 rounded-2xl space-y-6">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <FlaskConical className="w-4 h-4 text-cyan-400" />
            <span>Interactive Elements Explorer</span>
          </h2>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            {elements.map(el => (
              <div key={el.number} className="bg-slate-950 border border-slate-800 p-3 rounded-xl space-y-1">
                <div className="text-[10px] text-slate-400 font-mono">#{el.number}</div>
                <div className="text-xl font-extrabold text-cyan-300">{el.symbol}</div>
                <div className="text-xs font-bold text-white truncate">{el.name}</div>
                <div className="text-[10px] text-slate-400">{el.mass} u</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
