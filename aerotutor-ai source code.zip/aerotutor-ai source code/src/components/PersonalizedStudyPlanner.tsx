import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { Calendar, CheckCircle2, Circle, Clock, Plus, Sparkles, BookOpen } from "lucide-react";

export const PersonalizedStudyPlanner: React.FC = () => {
  const { studyTasks, toggleTaskCompletion, addStudyTask, user, setSection } = useApp();

  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [newTaskSubject, setNewTaskSubject] = useState("Aerospace Engineering");
  const [newTaskDate, setNewTaskDate] = useState("Today");

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;
    addStudyTask(newTaskTitle, newTaskSubject, newTaskDate);
    setNewTaskTitle("");
  };

  const completedCount = studyTasks.filter(t => t.completed).length;
  const progressPercent = studyTasks.length > 0 ? Math.round((completedCount / studyTasks.length) * 100) : 0;

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-2xl">
        <div>
          <h1 className="text-2xl font-extrabold text-white flex items-center gap-2.5">
            <Calendar className="w-6 h-6 text-cyan-400" />
            <span>Personalized Study Planner</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            AI-optimized study roadmap aligned with your skill level, exam targets, and learning goals.
          </p>
        </div>

        <div className="bg-slate-950 border border-slate-800 px-4 py-2.5 rounded-xl text-xs space-y-1 min-w-[180px]">
          <div className="flex justify-between text-slate-400">
            <span>Overall Roadmap</span>
            <span className="font-bold text-cyan-400">{progressPercent}%</span>
          </div>
          <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden">
            <div className="bg-cyan-400 h-full rounded-full transition-all" style={{ width: `${progressPercent}%` }} />
          </div>
        </div>
      </div>

      {/* Add Task Bar */}
      <form onSubmit={handleAddTask} className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex flex-col sm:flex-row gap-3">
        <input
          type="text"
          value={newTaskTitle}
          onChange={e => setNewTaskTitle(e.target.value)}
          placeholder="Add custom study task (e.g. Solve 5 Compressible Flow equations)..."
          className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
        />

        <select
          value={newTaskSubject}
          onChange={e => setNewTaskSubject(e.target.value)}
          className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
        >
          <option>Aerospace Engineering</option>
          <option>Physics</option>
          <option>Mathematics</option>
          <option>Computer Science</option>
        </select>

        <button
          type="submit"
          className="px-5 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Add Task</span>
        </button>
      </form>

      {/* Task List */}
      <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
        <h2 className="text-base font-bold text-white flex items-center justify-between">
          <span>Active Study Tasks & Milestones</span>
          <span className="text-xs text-slate-400 font-mono">
            {completedCount} of {studyTasks.length} Done
          </span>
        </h2>

        <div className="space-y-3">
          {studyTasks.map(task => (
            <div
              key={task.id}
              onClick={() => toggleTaskCompletion(task.id)}
              className={`p-4 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-4 ${
                task.completed
                  ? "bg-slate-950/60 border-slate-800/80 text-slate-500"
                  : "bg-slate-950 border-slate-800 hover:border-cyan-500/40 text-slate-200"
              }`}
            >
              <div className="flex items-center gap-3">
                <button className="text-cyan-400">
                  {task.completed ? <CheckCircle2 className="w-5 h-5 text-emerald-400" /> : <Circle className="w-5 h-5 text-slate-600" />}
                </button>
                <div>
                  <div className={`text-xs font-bold ${task.completed ? "line-through text-slate-500" : "text-white"}`}>
                    {task.taskTitle}
                  </div>
                  <div className="text-[10px] text-slate-400 flex items-center gap-2 mt-0.5">
                    <span className="px-1.5 py-0.2 rounded bg-slate-900 border border-slate-800">{task.subject}</span>
                    <span>Due: {task.dueDate}</span>
                  </div>
                </div>
              </div>

              <div className="text-[11px] font-mono text-cyan-400 font-semibold shrink-0">
                {task.estimatedMinutes} mins
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
