import React, { useState } from "react";
import { AppProvider, useApp } from "./context/AppContext";
import { Navigation } from "./components/Navigation";
import { HackathonDemoBar } from "./components/HackathonDemoBar";
import { LandingPage } from "./components/LandingPage";
import { Dashboard } from "./components/Dashboard";
import { AITutor } from "./components/AITutor";
import { DocumentLibrary } from "./components/DocumentLibrary";
import { SummaryEngine } from "./components/SummaryEngine";
import { QuizGenerator } from "./components/QuizGenerator";
import { PracticeArena } from "./components/PracticeArena";
import { VoiceTutor } from "./components/VoiceTutor";
import { AerospaceLab } from "./components/AerospaceLab";
import { STEMLab } from "./components/STEMLab";
import { Analytics } from "./components/Analytics";
import { PersonalizedStudyPlanner } from "./components/PersonalizedStudyPlanner";
import { AccessibilitySettings } from "./components/AccessibilitySettings";
import { AuthModal } from "./components/AuthModal";

const AppContent: React.FC = () => {
  const { currentSection, accessibility } = useApp();
  const [isAuthOpen, setIsAuthOpen] = useState(false);

  return (
    <div
      className={`min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200 ${
        accessibility.highContrast ? "contrast-125" : ""
      } ${accessibility.dyslexicFont ? "font-serif tracking-wide" : ""}`}
    >
      {/* Hackathon Judge Demo Stepper Bar */}
      <HackathonDemoBar />

      <div className="flex-1 flex flex-col md:flex-row min-h-0 relative">
        {/* Responsive Sidebar Navigation */}
        <Navigation onOpenAuth={() => setIsAuthOpen(true)} />

        {/* Main Content Workspace View */}
        <main className="flex-1 overflow-y-auto min-w-0 pb-12 md:pb-0">
          {currentSection === "landing" && <LandingPage />}
          {currentSection === "dashboard" && <Dashboard />}
          {currentSection === "tutor" && <AITutor />}
          {currentSection === "library" && <DocumentLibrary />}
          {currentSection === "summary" && <SummaryEngine />}
          {currentSection === "quiz" && <QuizGenerator />}
          {currentSection === "practice" && <PracticeArena />}
          {currentSection === "voice" && <VoiceTutor />}
          {currentSection === "aerospace-lab" && <AerospaceLab />}
          {currentSection === "stem-lab" && <STEMLab />}
          {currentSection === "analytics" && <Analytics />}
          {currentSection === "planner" && <PersonalizedStudyPlanner />}
          {currentSection === "accessibility" && <AccessibilitySettings />}
        </main>
      </div>

      {/* Onboarding and Profile Modal */}
      <AuthModal isOpen={isAuthOpen} onClose={() => setIsAuthOpen(false)} />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
